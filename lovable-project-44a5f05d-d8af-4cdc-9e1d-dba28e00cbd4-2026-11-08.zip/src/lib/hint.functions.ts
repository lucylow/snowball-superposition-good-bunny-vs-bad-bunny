import { createServerFn } from "@tanstack/react-start";
import { generateResponse, GatewayError } from "@lovable.dev/ai-gateway";

type HintInput = {
  question: string;
  title: string;
  objective: string;
  lesson: string;
  hint: string;
  circuit: string;
};

export const askMissionHint = createServerFn({ method: "POST" })
  .inputValidator((d: HintInput) => {
    const q = String(d.question ?? "").trim().slice(0, 500);
    if (!q) throw new Error("Please type a question.");
    const s = (v: unknown) => String(v ?? "").slice(0, 1500);
    return { question: q, title: s(d.title), objective: s(d.objective), lesson: s(d.lesson), hint: s(d.hint), circuit: s(d.circuit) };
  })
  .handler(async ({ data }) => {
    try {
      const res = await generateResponse({
        model: "openai/gpt-6-astra",
        instructions:
          "You are Good Bunny, a friendly quantum computing tutor in a kids' puzzle game. Give a short, encouraging hint (max 3 sentences) that nudges the player toward solving the mission. Never give the full gate-by-gate solution.",
        input: `Mission: ${data.title}\nObjective: ${data.objective}\nLesson: ${data.lesson}\nBuilt-in hint: ${data.hint}\nPlayer's current circuit: ${data.circuit || "(empty)"}\n\nPlayer asks: ${data.question}`,
      });
      const text = res.output
        .flatMap((o) => (o.type === "message" ? o.content : []))
        .map((c) => (c.type === "output_text" ? c.text : ""))
        .join("")
        .trim();
      return { hint: text || "Hmm, Good Bunny is thinking… try asking another way!", error: null };
    } catch (e) {
      console.error("hint error", e instanceof GatewayError ? e.code : e);
      return { hint: null, error: "Good Bunny couldn't answer right now. Please try again in a moment." };
    }
  });
