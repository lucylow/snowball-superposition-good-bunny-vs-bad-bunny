import { createServerFn } from "@tanstack/react-start";
import { generateResponse, GatewayError } from "@lovable.dev/ai-gateway";

type ChallengeInput = {
  mission: string;
  objective: string;
  circuit: string;
  completed: number;
  total: number;
  carrots: number;
  gates: string;
  note: string;
};

export const suggestChallenge = createServerFn({ method: "POST" })
  .inputValidator((d: ChallengeInput) => {
    const s = (v: unknown, n = 800) => String(v ?? "").slice(0, n);
    const num = (v: unknown) => (Number.isFinite(Number(v)) ? Math.max(0, Math.floor(Number(v))) : 0);
    return {
      mission: s(d.mission, 200), objective: s(d.objective), circuit: s(d.circuit),
      completed: num(d.completed), total: num(d.total), carrots: num(d.carrots),
      gates: s(d.gates, 300), note: s(d.note, 300),
    };
  })
  .handler(async ({ data }) => {
    try {
      const res = await generateResponse({
        model: "openai/gpt-6-astra",
        instructions:
          "You are Good Bunny, a playful quantum computing coach in a kids' puzzle game. Suggest ONE personalized next practice challenge that builds just beyond the player's current skills. Format: a fun title on the first line, then 2-3 short sentences describing the goal and which gates to try. Do not give the full solution.",
        input: `Current mission: ${data.mission}\nObjective: ${data.objective}\nCurrent circuit: ${data.circuit || "(empty)"}\nMissions completed: ${data.completed}/${data.total}\nCarrot coins: ${data.carrots}\nGates learned: ${data.gates || "none yet"}\nPlayer note: ${data.note || "(none)"}`,
      });
      const text = res.output
        .flatMap((o) => (o.type === "message" ? o.content : []))
        .map((c) => (c.type === "output_text" ? c.text : ""))
        .join("")
        .trim();
      return { challenge: text || null, error: text ? null : "No challenge came back. Try again!" };
    } catch (e) {
      console.error("challenge error", e instanceof GatewayError ? e.code : e);
      return { challenge: null, error: "Good Bunny couldn't dream up a challenge right now. Please try again soon." };
    }
  });
