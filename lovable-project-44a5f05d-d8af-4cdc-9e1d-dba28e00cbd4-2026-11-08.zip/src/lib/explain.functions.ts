import { createServerFn } from "@tanstack/react-start";
import { generateResponse, GatewayError } from "@lovable.dev/ai-gateway";

export const explainCircuit = createServerFn({ method: "POST" })
  .inputValidator((d: { circuit: string; output: string }) => {
    const circuit = String(d.circuit ?? "").trim().slice(0, 1000);
    const output = String(d.output ?? "").trim().slice(0, 500);
    if (!circuit) throw new Error("Add a circuit first.");
    return { circuit, output };
  })
  .handler(async ({ data }) => {
    try {
      const res = await generateResponse({
        model: "openai/gpt-6-astra",
        instructions:
          "You are Good Bunny, a friendly quantum tutor for kids. Explain step by step how each gate in the circuit changed the qubit state and contributed to the observed output. Use a short bullet per gate, then one sentence summary. Keep it simple and accurate.",
        input: `Circuit (in order): ${data.circuit}\nObserved output: ${data.output || "(not given)"}`,
      });
      const text = res.output
        .flatMap((o) => (o.type === "message" ? o.content : []))
        .map((c) => (c.type === "output_text" ? c.text : ""))
        .join("")
        .trim();
      return { text: text || null, error: text ? null : "No explanation came back. Try again!" };
    } catch (e) {
      console.error("explain error", e instanceof GatewayError ? e.code : e);
      return { text: null, error: "Good Bunny couldn't explain right now. Please try again soon." };
    }
  });
