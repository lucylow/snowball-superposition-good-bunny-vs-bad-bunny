import { createFileRoute, ClientOnly } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import "../bunny.css";

const BunnyApp = lazy(() => import("../BunnyApp"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Good Bunny Quantum Showdown" },
      { name: "description", content: "Learn quantum gates by playing bunny missions." },
      { property: "og:title", content: "Good Bunny Quantum Showdown" },
      { property: "og:description", content: "Learn quantum gates by playing bunny missions." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <ClientOnly>
      <Suspense fallback={null}>
        <BunnyApp />
      </Suspense>
    </ClientOnly>
  ),
});
