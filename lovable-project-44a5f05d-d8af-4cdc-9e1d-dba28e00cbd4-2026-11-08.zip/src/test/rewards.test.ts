import { describe, it, expect } from "vitest";
import { getLevel, getBadges } from "@/game/rewards";
import { DEFAULT_PROGRESS } from "@/game/progress";

describe("rewards", () => {
  it("levels up every 50 carrots", () => {
    expect(getLevel(0).level).toBe(1);
    expect(getLevel(49).level).toBe(1);
    expect(getLevel(50).level).toBe(2);
  });
  it("awards First Sprout after one mission", () => {
    const b = getBadges({ ...DEFAULT_PROGRESS, completedMissionIds: ["m1"] }, 10);
    expect(b.find((x) => x.id === "first")?.earned).toBe(true);
    expect(b.find((x) => x.id === "all")?.earned).toBe(false);
  });
});
