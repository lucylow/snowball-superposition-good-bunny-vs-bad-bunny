import { CircuitInsights, FamousCircuits } from "./components/CircuitInsights";
import MotionSettings from "./components/MotionSettings";
// @ts-nocheck
import { useEffect, useMemo, useState } from "react";
import {
  appendOperation,
  clearCircuit,
  createCircuit,
  createOperation,
  removeOperation,
  type Circuit,
} from "./quantum/circuit";
import { runCircuit } from "./quantum/simulator";
import { type GateKind } from "./quantum/gates";
import { MISSIONS, getUnlockedMissionIds } from "./game/missions";
import { evaluateMission } from "./game/missionEngine";
import { useProgress } from "./hooks/useProgress";
import { useSound } from "./hooks/useSound";
import BunnyMascot from "./components/BunnyMascot";
import CircuitBoard from "./components/CircuitBoard";
import GateShelf from "./components/GateShelf";
import LearningPanel from "./components/LearningPanel";
import MissionCard, { MissionIntro } from "./components/MissionCard";
import ProbabilityPanel from "./components/ProbabilityPanel";
import ShotPanel from "./components/ShotPanel";
import AskBunny from "./components/AskBunny";
import RewardsBar from "./components/RewardsBar";
import NextChallenge from "./components/NextChallenge";
import ExplainCircuit from "./components/ExplainCircuit";
import PracticeArena from "./components/PracticeArena";
import type { Mission } from "./game/types";
import type { CircuitExecution } from "./quantum/simulator";

const FIRST_MISSION = MISSIONS[0] as Mission;

const TWO_WIRE_GATES: GateKind[] = ["CNOT", "CZ", "SWAP"];

type MainTab = "adventure" | "arcade" | "field-guide";

export default function App() {
  const { progress, markMissionComplete, toggleSound, resetProgress } = useProgress();
  const playSound = useSound(progress.soundEnabled);
  const [missionId, setMissionId] = useState(FIRST_MISSION.id);
  const mission = MISSIONS.find((entry) => entry.id === missionId) ?? FIRST_MISSION;
  const [circuit, setCircuit] = useState<Circuit>(() => createCircuit(mission.qubitCount));
  const [targetWire, setTargetWire] = useState(0);
  const [controlWire, setControlWire] = useState(1);
  const [thetaDegrees, setThetaDegrees] = useState(60);
  const [lastExecution, setLastExecution] = useState<CircuitExecution | null>(null);
  const [recentGate, setRecentGate] = useState<GateKind | null>(null);
  const [activeTab, setActiveTab] = useState<MainTab>("adventure");
  const [toast, setToastText] = useState<string | null>(null);
  const [toastKey, setToastKey] = useState(0);
  const setToast = (text: string | null) => { setToastText(text); if (text) setToastKey((k) => k + 1); };
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const unlockedMissionIds = useMemo(
    () => new Set(getUnlockedMissionIds(progress.completedMissionIds)),
    [progress.completedMissionIds],
  );
  const completed = progress.completedMissionIds.includes(mission.id);
  const evaluation = useMemo(() => evaluateMission(circuit, mission), [circuit, mission]);
  const previewExecution = useMemo(
    () => runCircuit(circuit, { skipMeasurements: true }),
    [circuit],
  );
  const currentState = lastExecution?.finalState ?? previewExecution.finalState;
  const allGateKinds = useMemo(
    () => [...new Set(circuit.operations.map((operation) => operation.kind))],
    [circuit.operations],
  );
  const completedCount = progress.completedMissionIds.length;
  const progressPercent = Math.round((completedCount / MISSIONS.length) * 100);

  useEffect(() => {
    setCircuit(createCircuit(mission.qubitCount));
    setTargetWire(mission.qubitCount > 1 ? 1 : 0);
    setControlWire(0);
    setThetaDegrees(60);
    setLastExecution(null);
    setRecentGate(null);
  }, [missionId, mission.qubitCount]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const selectMission = (next: Mission) => {
    if (!unlockedMissionIds.has(next.id)) return;
    setMissionId(next.id);
    setActiveTab("adventure");
    playSound("tap");
  };

  const addGate = (kind: GateKind) => {
    const hasTerminalMeasurement = circuit.operations.some((operation) => operation.kind === "MEASURE");
    if (hasTerminalMeasurement) {
      setToast(kind === "MEASURE"
        ? "This lab uses one terminal measurement. Remove the existing M gate first."
        : "Measurement is a terminal readout in this lab. Remove M before adding more gates.");
      playSound("error");
      return;
    }
    if (TWO_WIRE_GATES.includes(kind) && mission.qubitCount < 2) {
      setToast("This carrot trick needs at least two qubit wires. Try an island mission!");
      playSound("error");
      return;
    }
    let target = Math.min(targetWire, mission.qubitCount - 1);
    let control = Math.min(controlWire, mission.qubitCount - 1);
    if (TWO_WIRE_GATES.includes(kind) && control === target) {
      control = target === 0 ? 1 : 0;
      setControlWire(control);
      setTargetWire(target);
    }
    const operation = createOperation(kind, target, {
      ...(TWO_WIRE_GATES.includes(kind) ? { control } : {}),
      ...(kind === "RX" || kind === "RY" || kind === "RZ"
        ? { theta: (thetaDegrees * Math.PI) / 180 }
        : {}),
    });
    try {
      setCircuit((current) => appendOperation(current, operation));
      setLastExecution(null);
      setRecentGate(kind);
      playSound(kind === "MEASURE" ? "measure" : "gate");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "That gate could not be added.");
      playSound("error");
    }
  };

  const removeGate = (id: string) => {
    setCircuit((current) => removeOperation(current, id));
    setLastExecution(null);
    playSound("tap");
  };

  const runCurrentCircuit = () => {
    try {
      const result = runCircuit(circuit);
      setLastExecution(result);
      if (result.measurements.length > 0) {
        const outcomes = result.measurements.map((measurement) => `q${measurement.qubit} → ${measurement.outcome}`).join(" · ");
        setToast(`Measured! ${outcomes}. The state has collapsed.`);
        playSound("measure");
      } else {
        setToast("Circuit simulated! Inspect the amplitudes and probabilities.");
        playSound("gate");
      }
    } catch (error) {
      setToast(error instanceof Error ? error.message : "The circuit could not run.");
      playSound("error");
    }
  };

  const resetCircuit = () => {
    setCircuit((current) => clearCircuit(current));
    setLastExecution(null);
    setRecentGate(null);
    setToast("Fresh circuit! The bunny is ready for another attempt.");
    playSound("tap");
  };

  const claimMission = () => {
    if (!evaluation.passed || completed) return;
    markMissionComplete(mission.id, mission.carrotReward, circuit.operations.length, allGateKinds);
    setToast(`Mission complete! +${mission.carrotReward} carrot coins 🥕`);
    playSound("success");
  };

  const openNextMission = () => {
    const next = MISSIONS.find((entry) => unlockedMissionIds.has(entry.id) && !progress.completedMissionIds.includes(entry.id));
    if (next) selectMission(next);
  };

  return (
    <div className="app-shell">
      <div className="ambient ambient--one" />
      <div className="ambient ambient--two" />
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark"><BunnyMascot size={42} compact mood="happy" /></div>
          <div className="brand-wordmark">
            <strong>GOOD BUNNY <span>vs</span> BAD BUNNY</strong>
            <small>QUANTUM SHOWDOWN</small>
          </div>
        </div>
        <nav className="topnav" aria-label="Main navigation">
          <button className={activeTab === "adventure" ? "is-active" : ""} onClick={() => setActiveTab("adventure")} type="button">🥕 Adventure</button>
          <button className={activeTab === "arcade" ? "is-active" : ""} onClick={() => setActiveTab("arcade")} type="button">🥕 Arcade</button>
          <button className={activeTab === "field-guide" ? "is-active" : ""} onClick={() => setActiveTab("field-guide")} type="button">📖 Field guide</button>
        </nav>
        <div className="topbar__actions">
          <MotionSettings />
          <div className="carrot-wallet" title="Carrot coins earned"><span>🥕</span><strong>{progress.carrotCount}</strong></div>
          <button className="icon-button sound-toggle" type="button" onClick={toggleSound} title={progress.soundEnabled ? "Mute sounds" : "Enable sounds"} aria-label={progress.soundEnabled ? "Mute sounds" : "Enable sounds"}>
            {progress.soundEnabled ? "♫" : "♪̸"}
          </button>
        </div>
      </header>

      {activeTab === "adventure" ? (
        <main className="main-layout">
          <aside className="campaign-sidebar">
            <div className="sidebar-heading">
              <span className="eyebrow">THE CARROT CHRONICLES</span>
              <h2>Adventure map</h2>
              <p>12 tiny hops to quantum mastery.</p>
            </div>
            <div className="campaign-progress">
              <div className="campaign-progress__top"><span>Campaign progress</span><strong>{completedCount}/{MISSIONS.length}</strong></div>
              <div className="progress-track"><span style={{ width: `${progressPercent}%` }} /></div>
              <small>{progressPercent}% of the multiverse saved</small>
            </div>
            <div className="mission-list">
              {MISSIONS.map((entry) => (
                <MissionCard
                  key={entry.id}
                  mission={entry}
                  completed={progress.completedMissionIds.includes(entry.id)}
                  active={entry.id === mission.id}
                  locked={!unlockedMissionIds.has(entry.id)}
                  onSelect={() => selectMission(entry)}
                />
              ))}
            </div>
            <div className="sidebar-bunny-tip">
              <BunnyMascot size={58} mood="thinking" compact />
              <p><strong>One bunny, two labels.</strong><br />Good = |0⟩ and Bad = |1⟩ in this game's teaching metaphor.</p>
            </div>
            <button className="text-button reset-progress-button" type="button" onClick={() => setShowResetConfirm(true)}>Reset all progress</button>
          </aside>

          <section className="game-column">
            <div className="game-hero">
              <div className="game-hero__copy">
                <span className="eyebrow">A CARROT-POWERED QUANTUM ADVENTURE</span>
                <h1>One bunny.<br /><em>Two states.</em> Infinite mischief.</h1>
                <p>Build real quantum circuits, solve bunny-sized puzzles, and save the carrot multiverse.</p>
                <div className="hero-tags"><span>⚛️ Learn by building</span><span>🥕 Earn carrot coins</span><span>🐰 Bunny-certified chaos</span></div>
              </div>
              <div className="game-hero__art">
                <div className="orbit orbit--one" /><div className="orbit orbit--two" />
                <span className="floating-carrot carrot-a">🥕</span>
                <span className="floating-carrot carrot-b">🥕</span>
                <span className="floating-symbol symbol-a">|0⟩</span>
                <span className="floating-symbol symbol-b">|1⟩</span>
                <BunnyMascot size={190} mood="mischievous" />
              </div>
            </div>

            <MissionIntro mission={mission} />

            <section className="workbench-card">
              <div className="workbench-heading">
                <div>
                  <span className="eyebrow">HANDS-ON QUANTUM LAB</span>
                  <h2>Build the bunny's circuit</h2>
                </div>
                <div className="workbench-actions">
                  <button type="button" className="button button--ghost button--small" onClick={resetCircuit}>↺ Reset</button>
                  <button type="button" className="button button--primary button--small" onClick={runCurrentCircuit}>▶ Run circuit</button>
                </div>
              </div>
              <div className="wire-controls">
                <label>Target wire
                  <select value={targetWire} onChange={(event) => setTargetWire(Number(event.target.value))}>
                    {Array.from({ length: mission.qubitCount }, (_, index) => <option value={index} key={index}>q{index}</option>)}
                  </select>
                </label>
                {mission.qubitCount > 1 && <label>Control / second wire
                  <select value={controlWire} onChange={(event) => setControlWire(Number(event.target.value))}>
                    {Array.from({ length: mission.qubitCount }, (_, index) => <option value={index} key={index}>q{index}</option>)}
                  </select>
                </label>}
                <label>Rotation angle
                  <select value={thetaDegrees} onChange={(event) => setThetaDegrees(Number(event.target.value))}>
                    <option value={30}>30° (π/6)</option>
                    <option value={45}>45° (π/4)</option>
                    <option value={60}>60° (π/3)</option>
                    <option value={90}>90° (π/2)</option>
                    <option value={120}>120° (2π/3)</option>
                    <option value={180}>180° (π)</option>
                  </select>
                </label>
              </div>
              <GateShelf onAdd={addGate} />
              <CircuitBoard circuit={circuit} onRemove={removeGate} />
              <CircuitInsights circuit={circuit} />
              <div className="workbench-bottom">
                <div className={`mission-check${evaluation.passed ? " mission-check--passed" : ""}`}>
                  <div className="mission-check__icon">{evaluation.passed ? "🎉" : "🥕"}</div>
                  <div className="mission-check__copy">
                    <strong>{evaluation.passed ? "Quantum mission solved!" : "Mission objective"}</strong>
                    <p>{evaluation.message}</p>
                  </div>
                  {evaluation.passed && !completed && <button type="button" className="button button--success" onClick={claimMission}>Claim carrots</button>}
                  {completed && <span className="completed-stamp">✓ Completed</span>}
                </div>
                {completed && <button type="button" className="button button--primary next-mission-button" onClick={openNextMission}>Next mission →</button>}
              </div>
            </section>

            <div className="inspector-grid">
              <ProbabilityPanel state={currentState} collapsed={Boolean(lastExecution?.measurements.length)} />
              <ShotPanel state={previewExecution.finalState} />
            </div>
            <RewardsBar progress={progress} totalMissions={MISSIONS.length} />
            <LearningPanel mission={mission} recentGate={recentGate} />
            <AskBunny mission={mission} circuit={circuit.operations.map((o: any) => `${o.kind}@q${o.target}${o.control!==undefined?`(ctrl q${o.control})`:""}`).join(", ")} />
            <NextChallenge mission={mission} progress={progress} total={MISSIONS.length} circuit={circuit.operations.map((o: any) => `${o.kind}@q${o.target}${o.control!==undefined?`(ctrl q${o.control})`:""}`).join(", ")} />
            <ExplainCircuit circuit={circuit.operations.map((o: any) => `${o.kind}@q${o.target}${o.control!==undefined?`(ctrl q${o.control})`:""}`).join(", ")} />
            <footer className="app-footer">
              <span>Made for curious minds and hungry bunnies.</span>
              <span>Local simulator · No account · Progress saved on this device</span>
            </footer>
          </section>
        </main>
      ) : activeTab === "arcade" ? (
        <PracticeArena />
      ) : (
        <FieldGuide onBack={() => setActiveTab("adventure")} />
      )}

      {toast && (
        <>
          <div key={`flash-${toastKey}`} className="error-flash" aria-hidden="true" />
          <div key={`toast-${toastKey}`} className="toast toast-error" role="status">
            <span className="toast-error-icon" aria-hidden="true">!</span>
            <span>{toast}</span>
            <span className="toast-error-timer" aria-hidden="true" />
          </div>
        </>
      )}
      {showResetConfirm && (
        <div className="modal-backdrop" role="presentation" onClick={() => setShowResetConfirm(false)}>
          <div className="confirm-modal" role="dialog" aria-modal="true" aria-labelledby="reset-title" onClick={(event) => event.stopPropagation()}>
            <BunnyMascot size={84} mood="thinking" />
            <h2 id="reset-title">Start a fresh carrot patch?</h2>
            <p>This clears completed missions and carrot coins on this device. Your circuits are not uploaded anywhere.</p>
            <div className="modal-actions">
              <button type="button" className="button button--ghost" onClick={() => setShowResetConfirm(false)}>Keep my progress</button>
              <button type="button" className="button button--danger" onClick={() => { resetProgress(); setShowResetConfirm(false); setMissionId(MISSIONS[0]!.id); resetCircuit(); }}>Reset progress</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FieldGuide({ onBack }: { onBack: () => void }) {
  const concepts = [
    { title: "Qubits", tag: "The bunny's quantum bit", equation: "|ψ⟩ = α|0⟩ + β|1⟩", body: "A qubit is described by two complex amplitudes. For a normalized pure state, |α|² + |β|² = 1. Good and Bad are playful labels for |0> and |1> in the game." },
    { title: "Hadamard gate", tag: "The possibility sprinkler", equation: "H = 1/√2 [ [1, 1], [1, −1] ]", body: "The Hadamard gate mixes computational-basis amplitudes. H|0> gives an equal superposition of |0> and |1>. H|1> gives the minus superposition." },
    { title: "Pauli-X gate", tag: "The carrot flip", equation: "X|0⟩ = |1⟩   ·   X|1⟩ = |0⟩", body: "Pauli-X exchanges the basis states. It is the quantum version of a NOT operation on a computational-basis bit." },
    { title: "Phase gates", tag: "The invisible twist", equation: "Z = diag(1, −1)   ·   S = diag(1, i)", body: "Phase gates change the relative phase between amplitudes. Phase may not change immediate measurement probabilities, but it can change interference after later gates." },
    { title: "Entanglement", tag: "Two baskets, one shared state", equation: "(|00⟩ + |11⟩)/√2", body: "Entangled states cannot be written as a product of independent single-qubit states. A Hadamard followed by CNOT can create a Bell state." },
    { title: "Measurement", tag: "Open the carrot parcel", equation: "P(0) = |α|²   ·   P(1) = |β|²", body: "A computational-basis measurement samples an outcome according to the squared magnitude of its amplitude and projects the state onto the corresponding outcome subspace." },
    { title: "Rotation gates", tag: "The carrot dial", equation: "RY(θ)|0⟩ = cos(θ/2)|0⟩ + sin(θ/2)|1⟩", body: "RX, RY and RZ rotate the state around an axis of the Bloch sphere by angle θ. RY lets you choose any measurement probability you like: P(1) = sin²(θ/2)." },
    { title: "Bloch sphere", tag: "The bunny's globe", equation: "|ψ⟩ = cos(θ/2)|0⟩ + e^{iφ} sin(θ/2)|1⟩", body: "Every single-qubit pure state is a point on a sphere. The north pole is |0>, the south pole is |1>, and the equator holds equal superpositions that differ only in phase." },
    { title: "Interference", tag: "Carrot waves meet", equation: "H · H = I", body: "Amplitudes can add or cancel like waves. Applying H twice returns |0> because the two paths to |1> have opposite signs and cancel out. Quantum algorithms are built on this trick." },
    { title: "CZ and SWAP", tag: "Two-basket tricks", equation: "CZ|11⟩ = −|11⟩   ·   SWAP|01⟩ = |10⟩", body: "CZ adds a minus sign only when both qubits are 1, which is invisible alone but powerful with interference. SWAP exchanges the states of two qubits." },
    { title: "No-cloning", tag: "No copying carrots", equation: "|ψ⟩|0⟩ ↛ |ψ⟩|ψ⟩", body: "No quantum operation can make a perfect copy of an unknown quantum state. This is why quantum information is so different from classical data, and why quantum cryptography is secure." },
    { title: "Decoherence", tag: "The garden gets noisy", equation: "ρ → (1−p)ρ + p·ZρZ", body: "Real qubits leak information into their surroundings, slowly destroying superposition. Engineers fight this with cold fridges, isolation and quantum error correction." },
  ];
  return (
    <main className="field-guide-page">
      <button type="button" className="button button--ghost" onClick={onBack}>← Back to adventure</button>
      <div className="field-guide-hero">
        <BunnyMascot size={150} mood="happy" />
        <div><span className="eyebrow">THE BUNNY'S POCKET NOTEBOOK</span><h1>Quantum field guide</h1><p>Real quantum ideas, explained with carrots. No quantum fluff.</p></div>
      </div>
      <div className="field-guide-grid">
        {concepts.map((concept, index) => (
          <article className="concept-card" key={concept.title}>
            <span className="concept-card__number">{String(index + 1).padStart(2, "0")}</span>
            <small>{concept.tag}</small>
            <h2>{concept.title}</h2>
            <code>{concept.equation}</code>
            <p>{concept.body}</p>
          </article>
        ))}
      </div>
      <FamousCircuits />
      <QuantumQuiz />
      <section className="edu-section">
        <span className="eyebrow">QUANTUM HISTORY</span>
        <h2>From thought experiments to real chips</h2>
        <ol className="edu-timeline">
          {[
            ["1900", "Max Planck proposes that energy comes in tiny packets called quanta."],
            ["1926", "Erwin Schrödinger writes the wave equation that describes quantum states."],
            ["1935", "Einstein, Podolsky and Rosen question entanglement, calling it \"spooky action at a distance\"."],
            ["1964", "John Bell shows entanglement can be tested in experiments."],
            ["1981", "Richard Feynman suggests building computers that use quantum mechanics."],
            ["1994", "Peter Shor finds a quantum algorithm that factors large numbers quickly."],
            ["1996", "Lov Grover finds a quantum speed-up for searching unsorted lists."],
            ["2022", "The Nobel Prize in Physics honours experiments proving entanglement is real."],
          ].map(([year, text]) => (
            <li key={year}><strong>{year}</strong><span>{text}</span></li>
          ))}
        </ol>
      </section>
      <section className="edu-section">
        <span className="eyebrow">GLOSSARY</span>
        <h2>Bunny word list</h2>
        <dl className="edu-glossary">
          {[
            ["Amplitude", "A complex number whose squared size gives the chance of an outcome."],
            ["Superposition", "A state that combines several basis states at once."],
            ["Phase", "The angle of an amplitude. Invisible alone, but it steers interference."],
            ["Basis state", "One of the definite answers like |0>, |1>, |01> or |11>."],
            ["Bell state", "A maximally entangled two-qubit state, such as (|00> + |11>)/√2."],
            ["Shot", "One run of a circuit ending in a measurement. Many shots build a histogram."],
            ["Unitary", "A reversible operation that keeps total probability equal to 1. Every gate is one."],
            ["Qubit register", "A group of qubits used together. n qubits have 2ⁿ basis states."],
          ].map(([term, def]) => (
            <div key={term}><dt>{term}</dt><dd>{def}</dd></div>
          ))}
        </dl>
      </section>
      <div className="field-guide-note"><strong>Simulator note:</strong> This web app uses a classical state-vector simulator for learning. It does not connect to quantum hardware, and the Good/Bad labels are a teaching metaphor rather than a physical moral property of a qubit.</div>
    </main>
  );
}

const QUIZ = [
  { q: "What happens if you apply H twice to |0>?", options: ["You get |1>", "You get |0> back", "A 50/50 mix"], answer: 1, why: "The two paths to |1> cancel by interference, so H·H = I." },
  { q: "A qubit is in (|0> + |1>)/√2. What is P(1)?", options: ["25%", "50%", "100%"], answer: 1, why: "P(1) = |1/√2|² = 1/2." },
  { q: "Which gates make a Bell state from |00>?", options: ["X then Z", "H then CNOT", "Two SWAPs"], answer: 1, why: "H puts qubit 0 into superposition, then CNOT links qubit 1 to it." },
  { q: "Does a Z gate change measurement odds on its own?", options: ["Yes, always", "No, only the phase", "It measures the qubit"], answer: 1, why: "Z flips the sign of |1>, and |−β|² = |β|²." },
  { q: "How many basis states do 3 qubits have?", options: ["3", "6", "8"], answer: 2, why: "n qubits have 2ⁿ basis states: 2³ = 8." },
];

function QuantumQuiz() {
  const [picked, setPicked] = useState<Record<number, number>>({});
  const score = QUIZ.filter((item, i) => picked[i] === item.answer).length;
  return (
    <section className="edu-section">
      <span className="eyebrow">CARROT QUIZ</span>
      <h2>Test your quantum instincts</h2>
      <p className="edu-score">Score: {score} / {QUIZ.length}</p>
      <div className="edu-quiz">
        {QUIZ.map((item, i) => {
          const choice = picked[i];
          return (
            <article key={item.q} className="edu-question">
              <h3>{item.q}</h3>
              <div className="edu-options">
                {item.options.map((opt, j) => (
                  <button
                    key={opt}
                    type="button"
                    className={`edu-option${choice === undefined ? "" : j === item.answer ? " is-right" : choice === j ? " is-wrong" : ""}`}
                    disabled={choice !== undefined}
                    onClick={() => setPicked((p) => ({ ...p, [i]: j }))}
                  >
                    {opt}
                  </button>
                ))}
              </div>
              {choice !== undefined && (
                <p className={choice === item.answer ? "edu-why" : "edu-why inline-error"}>
                  {choice === item.answer ? "Correct! " : "Not quite. "}{item.why}
                </p>
              )}
            </article>
          );
        })}
      </div>
      <button type="button" className="button button--ghost" onClick={() => setPicked({})}>Reset quiz</button>
    </section>
  );
}
