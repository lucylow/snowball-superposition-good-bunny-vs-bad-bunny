import { useCallback, useEffect, useState } from "react";
import type { GateKind } from "../quantum/gates";
import { completeMission, loadProgress, saveProgress } from "../game/progress";
import type { PlayerProgress } from "../game/types";

export function useProgress() {
  const [progress, setProgress] = useState<PlayerProgress>(() => loadProgress());

  useEffect(() => {
    try {
      saveProgress(progress);
    } catch {
      // The game remains usable when browser storage is blocked or full.
    }
  }, [progress]);

  const markMissionComplete = useCallback((
    missionId: string,
    reward: number,
    circuitLength: number,
    learnedGates: GateKind[],
  ) => {
    setProgress((current) => completeMission(
      current,
      missionId,
      reward,
      circuitLength,
      learnedGates,
    ));
  }, []);

  const toggleSound = useCallback(() => {
    setProgress((current) => ({ ...current, soundEnabled: !current.soundEnabled }));
  }, []);

  const resetProgress = useCallback(() => {
    setProgress({
      completedMissionIds: [],
      carrotCount: 0,
      bestCircuitLengths: {},
      learnedGateKinds: [],
      lastPlayedAt: null,
      soundEnabled: true,
    });
  }, []);

  return { progress, markMissionComplete, toggleSound, resetProgress };
}
