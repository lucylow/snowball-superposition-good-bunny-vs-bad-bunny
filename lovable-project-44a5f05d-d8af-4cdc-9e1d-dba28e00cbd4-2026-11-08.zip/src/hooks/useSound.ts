import { useCallback, useRef } from "react";

export type SoundCue = "tap" | "gate" | "success" | "carrot" | "measure" | "error";

/** Small procedural sound effects: no external audio files or network calls. */
export function useSound(enabled: boolean) {
  const contextRef = useRef<AudioContext | null>(null);

  const play = useCallback((cue: SoundCue) => {
    if (!enabled || typeof window === "undefined") return;
    try {
      const AudioContextClass = window.AudioContext ||
        (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const context = contextRef.current ?? new AudioContextClass();
      contextRef.current = context;
      if (context.state === "suspended") void context.resume();

      const now = context.currentTime;
      const notes: Record<SoundCue, number[]> = {
        tap: [440],
        gate: [392, 587],
        success: [523.25, 659.25, 783.99],
        carrot: [659.25, 987.77],
        measure: [440, 330],
        error: [220, 185],
      };
      notes[cue].forEach((frequency, index) => {
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.type = cue === "error" ? "triangle" : "sine";
        oscillator.frequency.setValueAtTime(frequency, now + index * 0.075);
        gain.gain.setValueAtTime(0.0001, now + index * 0.075);
        gain.gain.exponentialRampToValueAtTime(0.07, now + index * 0.075 + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + index * 0.075 + 0.16);
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start(now + index * 0.075);
        oscillator.stop(now + index * 0.075 + 0.18);
      });
    } catch {
      // Sound is optional; audio restrictions must never block gameplay.
    }
  }, [enabled]);

  return play;
}
