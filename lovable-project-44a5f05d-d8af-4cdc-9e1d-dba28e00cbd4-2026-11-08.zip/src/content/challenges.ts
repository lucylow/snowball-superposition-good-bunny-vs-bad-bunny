// @ts-nocheck
export type ChallengeTopic =
  | "qubits"
  | "superposition"
  | "single-gates"
  | "phase"
  | "rotations"
  | "entanglement"
  | "measurement";

export interface PracticeChallenge {
  id: string;
  topic: ChallengeTopic;
  difficulty: "warm-up" | "crunchy" | "spicy";
  prompt: string;
  choices: [string, string, string, string];
  correctIndex: 0 | 1 | 2 | 3;
  explanation: string;
  hint: string;
  carrots: number;
}

const gateDefinitionChallenges: PracticeChallenge[] = [
  {
    id: "gate-h-01",
    topic: "superposition",
    difficulty: "warm-up",
    prompt: "Which gate creates an equal superposition when it acts on |0⟩?",
    choices: ["Hadamard (H)", "Pauli-X", "Pauli-Z", "CNOT"],
    correctIndex: 0,
    explanation: "H|0⟩ = (|0⟩ + |1⟩)/√2, so both computational-basis outcomes have probability 1/2.",
    hint: "Look for the gate that mixes the two computational-basis amplitudes.",
    carrots: 3,
  },
  {
    id: "gate-x-01",
    topic: "single-gates",
    difficulty: "warm-up",
    prompt: "Which gate exchanges |0⟩ and |1⟩?",
    choices: ["Pauli-Z", "Pauli-X", "Hadamard", "S gate"],
    correctIndex: 1,
    explanation: "Pauli-X maps |0⟩ to |1⟩ and |1⟩ to |0⟩. It is the quantum NOT gate.",
    hint: "This gate is often called a bit flip.",
    carrots: 3,
  },
  {
    id: "gate-z-01",
    topic: "phase",
    difficulty: "warm-up",
    prompt: "What does Pauli-Z do to the basis state |1⟩?",
    choices: ["Maps it to |0⟩", "Maps it to |+⟩", "Multiplies it by −1", "Leaves every superposition unchanged"],
    correctIndex: 2,
    explanation: "Z|1⟩ = −|1⟩. The basis label stays the same while the amplitude changes sign.",
    hint: "Check the diagonal entries of the Z matrix.",
    carrots: 3,
  },
  {
    id: "gate-s-01",
    topic: "phase",
    difficulty: "crunchy",
    prompt: "Which phase does the S gate add to the |1⟩ amplitude?",
    choices: ["π/2 radians", "π radians", "π/4 radians", "2π radians"],
    correctIndex: 0,
    explanation: "S = diag(1, i), and i = e^(iπ/2), so the |1⟩ component gains a π/2 phase.",
    hint: "The S gate is also known as the phase gate.",
    carrots: 4,
  },
  {
    id: "gate-t-01",
    topic: "phase",
    difficulty: "crunchy",
    prompt: "The T gate applies which phase to the |1⟩ amplitude?",
    choices: ["π/2", "π/8", "π/4", "π"],
    correctIndex: 2,
    explanation: "T = diag(1, e^(iπ/4)), so its |1⟩ component gains a π/4 phase.",
    hint: "The T gate adds half the phase angle of the S gate.",
    carrots: 4,
  },
  {
    id: "gate-y-01",
    topic: "single-gates",
    difficulty: "crunchy",
    prompt: "Which gate combines a basis flip with factors of +i and −i?",
    choices: ["Pauli-X", "Pauli-Y", "Pauli-Z", "Hadamard"],
    correctIndex: 1,
    explanation: "Pauli-Y has matrix [[0, −i], [i, 0]], so it flips basis states while adding imaginary phases.",
    hint: "It is the Pauli gate named after the middle axis of the Bloch sphere.",
    carrots: 4,
  },
  {
    id: "gate-rx-01",
    topic: "rotations",
    difficulty: "crunchy",
    prompt: "Which gate rotates a qubit around the Bloch sphere's X axis?",
    choices: ["RZ", "RY", "RX", "CZ"],
    correctIndex: 2,
    explanation: "RX(θ) is a rotation around the X axis by angle θ on the Bloch sphere.",
    hint: "The letters after R name the rotation axis.",
    carrots: 4,
  },
  {
    id: "gate-ry-01",
    topic: "rotations",
    difficulty: "crunchy",
    prompt: "Which rotation gate changes the polar angle of |0⟩ along the Y axis?",
    choices: ["RX", "RZ", "RY", "SWAP"],
    correctIndex: 2,
    explanation: "RY rotates about the Y axis. Acting on |0⟩, it changes the computational-basis measurement probabilities.",
    hint: "The rotation axis is included in the gate's name.",
    carrots: 4,
  },
  {
    id: "gate-cnot-01",
    topic: "entanglement",
    difficulty: "warm-up",
    prompt: "When does CNOT flip its target qubit?",
    choices: ["When the control is |1⟩", "When the target is |1⟩", "Every time it is applied", "Only when both qubits are |0⟩"],
    correctIndex: 0,
    explanation: "CNOT applies X to the target if and only if the control is 1 in the computational basis.",
    hint: "CNOT is a controlled NOT: one wire decides whether the other wire flips.",
    carrots: 3,
  },
  {
    id: "gate-cz-01",
    topic: "entanglement",
    difficulty: "crunchy",
    prompt: "Which computational-basis component receives a minus sign from CZ?",
    choices: ["|00⟩", "|01⟩", "|10⟩", "|11⟩"],
    correctIndex: 3,
    explanation: "CZ is diagonal with entries 1, 1, 1, −1; only the |11⟩ component changes sign.",
    hint: "Both control and target must be 1 for the controlled phase to activate.",
    carrots: 4,
  },
  {
    id: "gate-swap-01",
    topic: "entanglement",
    difficulty: "warm-up",
    prompt: "What does a SWAP gate do to two qubits?",
    choices: ["Measures both qubits", "Exchanges their states", "Creates a 50/50 state", "Flips both qubits"],
    correctIndex: 1,
    explanation: "SWAP exchanges the two wires' states. It does not itself measure or create superposition.",
    hint: "Imagine two carrot baskets trading places.",
    carrots: 3,
  },
  {
    id: "gate-measure-01",
    topic: "measurement",
    difficulty: "warm-up",
    prompt: "In a computational-basis measurement, what determines the chance of outcome 0?",
    choices: ["The real part of α", "The phase of β", "The squared magnitude |α|²", "The number of gates in the circuit"],
    correctIndex: 2,
    explanation: "For |ψ⟩ = α|0⟩ + β|1⟩, the probability of outcome 0 is |α|².",
    hint: "The Born rule uses squared amplitude magnitudes.",
    carrots: 3,
  },
];

const rotationAngles = [30, 45, 60, 90, 120, 135, 150, 180];

function makeRotationChallenge(angle: number, index: number): PracticeChallenge {
  const probability = Math.sin((angle * Math.PI) / 360) ** 2;
  const correct = Number((probability * 100).toFixed(1));
  const candidateValues = [
    correct,
    correct + 12,
    correct - 12,
    correct + 24,
    correct - 24,
    correct + 36,
    correct - 36,
    0,
    50,
    100,
  ].map((value) => Math.min(100, Math.max(0, Number(value.toFixed(1)))));
  const unique = [...new Set(candidateValues)];
  const choices = unique.slice(0, 4);
  const correctIndex = choices.indexOf(correct) as 0 | 1 | 2 | 3;
  const labels = choices.map((value) => `${value}%`);
  return {
    id: `ry-probability-${angle}`,
    topic: "rotations",
    difficulty: angle === 90 ? "warm-up" : "crunchy",
    prompt: `The bunny applies RY(${angle}°) to |0⟩. What is the probability of measuring |1⟩?`,
    choices: labels as [string, string, string, string],
    correctIndex,
    explanation: `For RY(θ)|0⟩, P(1) = sin²(θ/2). At θ = ${angle}°, this is ${correct}%.`,
    hint: "Use the half-angle, then square the sine. The probability is not the angle itself.",
    carrots: 5,
  };
}

function makeCnotChallenge(bits: string, control: 0 | 1, index: number): PracticeChallenge {
  const values = bits.split("").map(Number);
  const controlIndex = 1 - control;
  const targetIndex = control;
  const result = [...values];
  if (values[controlIndex] === 1) result[targetIndex] = 1 - result[targetIndex];
  const correct = result.join("");
  const near = [bits, bits === "00" ? "11" : "00", result.map((bit, position) => position === targetIndex ? 1 - bit : bit).join("")];
  const options = [...new Set([correct, ...near])];
  for (const fill of ["01", "10", "11", "00"]) {
    if (!options.includes(fill)) options.push(fill);
  }
  const choices = options.slice(0, 4) as [string, string, string, string];
  return {
    id: `cnot-${bits}-control-${control}-${index}`,
    topic: "entanglement",
    difficulty: "crunchy",
    prompt: `A CNOT acts on |${bits}⟩ with q${control} as control and the other wire as target. What is the output?`,
    choices: choices.map((value) => `|${value}⟩`) as [string, string, string, string],
    correctIndex: choices.indexOf(correct) as 0 | 1 | 2 | 3,
    explanation: `The control is q${control}. ${values[controlIndex] === 1 ? "It is 1, so the target flips." : "It is 0, so the target stays the same."} The output is |${correct}⟩.`,
    hint: "Read the control bit first. If it is 1, flip the target; otherwise leave both bits alone.",
    carrots: 5,
  };
}

const stateChallenges: PracticeChallenge[] = [
  {
    id: "state-plus-01",
    topic: "superposition",
    difficulty: "warm-up",
    prompt: "A qubit is prepared in |+⟩ = (|0⟩ + |1⟩)/√2. What are its computational-basis probabilities?",
    choices: ["0: 100%, 1: 0%", "0: 50%, 1: 50%", "0: 25%, 1: 75%", "0: 75%, 1: 25%"],
    correctIndex: 1,
    explanation: "Both amplitudes have magnitude 1/√2, so both squared magnitudes are 1/2.",
    hint: "Square the magnitude of each amplitude, not the amplitude's sign.",
    carrots: 3,
  },
  {
    id: "state-minus-01",
    topic: "phase",
    difficulty: "crunchy",
    prompt: "What is different between |+⟩ and |−⟩ = (|0⟩ − |1⟩)/√2 before any further gate is applied?",
    choices: ["Their measurement probabilities", "Their qubit count", "The relative phase of the |1⟩ amplitude", "The magnitude of the |0⟩ amplitude"],
    correctIndex: 2,
    explanation: "Both have 50/50 computational-basis probabilities, but the |1⟩ amplitude has opposite sign. That relative phase affects interference.",
    hint: "Compare the signs of the two amplitudes, not their magnitudes.",
    carrots: 4,
  },
  {
    id: "state-normalization-01",
    topic: "qubits",
    difficulty: "crunchy",
    prompt: "A pure qubit has amplitudes α = 1/2 and β = √3/2. What is |α|² + |β|²?",
    choices: ["1/2", "3/4", "1", "5/4"],
    correctIndex: 2,
    explanation: "(1/2)² + (√3/2)² = 1/4 + 3/4 = 1. The state is normalized.",
    hint: "Add the squared magnitudes of both amplitudes.",
    carrots: 4,
  },
  {
    id: "state-bell-01",
    topic: "entanglement",
    difficulty: "spicy",
    prompt: "A Bell state is (|00⟩ + |11⟩)/√2. If both qubits are measured in the computational basis, which outcomes can occur?",
    choices: ["Only 00 or 11", "Only 01 or 10", "All four outcomes equally", "Only 00"],
    correctIndex: 0,
    explanation: "Only |00⟩ and |11⟩ have nonzero amplitudes, each with probability 1/2.",
    hint: "Look for which basis kets actually appear in the state.",
    carrots: 6,
  },
  {
    id: "state-ghz-01",
    topic: "entanglement",
    difficulty: "spicy",
    prompt: "For the GHZ state (|000⟩ + |111⟩)/√2, what happens when all three qubits are measured in the computational basis?",
    choices: ["The three bits always match", "Exactly one bit is 1", "Exactly two bits are 1", "All eight bit strings are equally likely"],
    correctIndex: 0,
    explanation: "The state contains only |000⟩ and |111⟩, so all three measured bits agree in every shot.",
    hint: "Only two of the eight computational-basis states have nonzero amplitudes.",
    carrots: 6,
  },
  {
    id: "measurement-repeat-01",
    topic: "measurement",
    difficulty: "crunchy",
    prompt: "One measurement of |+⟩ returns 1. What does that single result prove about the original probability of 1?",
    choices: ["It was exactly 100%", "It was exactly 50%", "It was greater than 50%", "It does not determine the probability by itself"],
    correctIndex: 3,
    explanation: "A single shot is one random sample. Repeated measurements are needed to estimate the underlying distribution.",
    hint: "A one-time result is not the same thing as a long-run frequency.",
    carrots: 4,
  },
  {
    id: "measurement-collapse-01",
    topic: "measurement",
    difficulty: "crunchy",
    prompt: "After measuring a single qubit and obtaining 0 in the computational basis, what is its post-measurement state in the ideal projective-measurement model?",
    choices: ["|+⟩", "|−⟩", "|0⟩", "|1⟩"],
    correctIndex: 2,
    explanation: "The measurement projects the qubit onto the observed computational-basis state |0⟩.",
    hint: "The observed outcome labels the state after an ideal measurement in that basis.",
    carrots: 4,
  },
  {
    id: "interference-01",
    topic: "phase",
    difficulty: "spicy",
    prompt: "What does H followed by H do to any one-qubit state?",
    choices: ["Applies X", "Returns the original state", "Measures the state", "Adds a π/2 phase"],
    correctIndex: 1,
    explanation: "H is its own inverse, so H² = I and the original state is restored.",
    hint: "The Hadamard transform is reversible and is its own inverse.",
    carrots: 5,
  },
];

const cnotChallenges = [
  makeCnotChallenge("00", 0, 0),
  makeCnotChallenge("01", 0, 1),
  makeCnotChallenge("10", 0, 2),
  makeCnotChallenge("11", 0, 3),
  makeCnotChallenge("00", 1, 4),
  makeCnotChallenge("01", 1, 5),
  makeCnotChallenge("10", 1, 6),
  makeCnotChallenge("11", 1, 7),
];

const rotationChallenges = rotationAngles.map(makeRotationChallenge);

export const PRACTICE_CHALLENGES: PracticeChallenge[] = [
  ...gateDefinitionChallenges,
  ...stateChallenges,
  ...cnotChallenges,
  ...rotationChallenges,
];

export const CHALLENGES_BY_TOPIC = PRACTICE_CHALLENGES.reduce<Record<ChallengeTopic, PracticeChallenge[]>>(
  (grouped, challenge) => {
    grouped[challenge.topic].push(challenge);
    return grouped;
  },
  {
    qubits: [],
    superposition: [],
    "single-gates": [],
    phase: [],
    rotations: [],
    entanglement: [],
    measurement: [],
  },
);

export function getChallengeById(id: string): PracticeChallenge | undefined {
  return PRACTICE_CHALLENGES.find((challenge) => challenge.id === id);
}

export function getRandomChallenge(
  random: () => number = Math.random,
  topic?: ChallengeTopic,
): PracticeChallenge {
  const pool = topic ? CHALLENGES_BY_TOPIC[topic] : PRACTICE_CHALLENGES;
  if (pool.length === 0) throw new Error("No practice challenges are available for this topic.");
  const index = Math.floor(Math.min(Math.max(random(), 0), 1 - Number.EPSILON) * pool.length);
  return pool[index];
}

export function getNextUnseenChallenge(
  seenIds: string[],
  random: () => number = Math.random,
): PracticeChallenge | undefined {
  const unseen = PRACTICE_CHALLENGES.filter((challenge) => !seenIds.includes(challenge.id));
  if (unseen.length === 0) return undefined;
  const index = Math.floor(Math.min(Math.max(random(), 0), 1 - Number.EPSILON) * unseen.length);
  return unseen[index];
}
