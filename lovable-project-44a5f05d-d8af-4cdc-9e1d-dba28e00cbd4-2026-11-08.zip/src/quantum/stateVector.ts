// @ts-nocheck
import {
  ZERO,
  add,
  complex,
  magnitudeSquared,
  scale,
  type Complex,
} from "./complex";
import { multiplyMatrixVector, type Matrix2 } from "./matrix";

export interface QuantumState {
  qubitCount: number;
  amplitudes: Complex[];
}

export function zeroState(qubitCount = 1): QuantumState {
  validateQubitCount(qubitCount);
  const amplitudes = Array.from({ length: 2 ** qubitCount }, () => complex(0));
  amplitudes[0] = complex(1);
  return { qubitCount, amplitudes };
}

export function basisState(bitString: string): QuantumState {
  if (!/^[01]+$/.test(bitString)) {
    throw new Error("A basis state must be a non-empty bit string.");
  }
  const state = zeroState(bitString.length);
  const index = bitString.split("").reverse().reduce((value, bit, wire) =>
    value + (bit === "1" ? 2 ** wire : 0), 0);
  state.amplitudes = state.amplitudes.map((_, current) =>
    current === index ? complex(1) : complex(0));
  return state;
}

export function cloneState(state: QuantumState): QuantumState {
  return {
    qubitCount: state.qubitCount,
    amplitudes: state.amplitudes.map((amp) => complex(amp.re, amp.im)),
  };
}

export function validateQubitCount(qubitCount: number): void {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 8) {
    throw new Error("The simulator supports between 1 and 8 qubits.");
  }
}

export function stateNorm(state: QuantumState): number {
  return state.amplitudes.reduce((sum, amp) => sum + magnitudeSquared(amp), 0);
}

export function normalizeState(state: QuantumState): QuantumState {
  const norm = Math.sqrt(stateNorm(state));
  if (norm === 0) throw new Error("A zero vector cannot be normalized.");
  return {
    qubitCount: state.qubitCount,
    amplitudes: state.amplitudes.map((amp) => scale(amp, 1 / norm)),
  };
}

export function applySingleQubitMatrix(
  state: QuantumState,
  target: number,
  matrix: Matrix2,
): QuantumState {
  validateWire(state, target);
  const bit = 2 ** target;
  const amplitudes = state.amplitudes.map((amp) => complex(amp.re, amp.im));
  for (let base = 0; base < amplitudes.length; base += 1) {
    if ((base & bit) !== 0) continue;
    const zeroIndex = base;
    const oneIndex = base | bit;
    const [newZero, newOne] = multiplyMatrixVector(matrix, [
      amplitudes[zeroIndex],
      amplitudes[oneIndex],
    ]);
    amplitudes[zeroIndex] = newZero;
    amplitudes[oneIndex] = newOne;
  }
  return { qubitCount: state.qubitCount, amplitudes };
}

export function applyCNOT(
  state: QuantumState,
  control: number,
  target: number,
): QuantumState {
  validateDistinctWires(state, control, target);
  const controlBit = 2 ** control;
  const targetBit = 2 ** target;
  const amplitudes = state.amplitudes.map((amp) => complex(amp.re, amp.im));
  for (let index = 0; index < amplitudes.length; index += 1) {
    if ((index & controlBit) === 0 || (index & targetBit) !== 0) continue;
    const partner = index | targetBit;
    [amplitudes[index], amplitudes[partner]] = [amplitudes[partner], amplitudes[index]];
  }
  return { qubitCount: state.qubitCount, amplitudes };
}

export function applyCZ(
  state: QuantumState,
  control: number,
  target: number,
): QuantumState {
  validateDistinctWires(state, control, target);
  const controlBit = 2 ** control;
  const targetBit = 2 ** target;
  const amplitudes = state.amplitudes.map((amp, index) =>
    (index & controlBit) !== 0 && (index & targetBit) !== 0
      ? scale(amp, -1)
      : complex(amp.re, amp.im));
  return { qubitCount: state.qubitCount, amplitudes };
}

export function applySWAP(
  state: QuantumState,
  first: number,
  second: number,
): QuantumState {
  validateDistinctWires(state, first, second);
  const firstBit = 2 ** first;
  const secondBit = 2 ** second;
  const amplitudes = state.amplitudes.map((amp) => complex(amp.re, amp.im));
  for (let index = 0; index < amplitudes.length; index += 1) {
    const firstSet = (index & firstBit) !== 0;
    const secondSet = (index & secondBit) !== 0;
    if (firstSet || !secondSet) continue;
    const partner = index ^ firstBit ^ secondBit;
    [amplitudes[index], amplitudes[partner]] = [amplitudes[partner], amplitudes[index]];
  }
  return { qubitCount: state.qubitCount, amplitudes };
}

export function probabilities(state: QuantumState): number[] {
  return state.amplitudes.map(magnitudeSquared);
}

export function qubitProbabilities(
  state: QuantumState,
  qubit: number,
): { zero: number; one: number } {
  validateWire(state, qubit);
  const bit = 2 ** qubit;
  let zero = 0;
  let one = 0;
  state.amplitudes.forEach((amplitude, index) => {
    if ((index & bit) === 0) zero += magnitudeSquared(amplitude);
    else one += magnitudeSquared(amplitude);
  });
  return { zero, one };
}

export function stateToDirac(state: QuantumState, digits = 3): string {
  const parts: string[] = [];
  state.amplitudes.forEach((amplitude, index) => {
    const probabilityAmplitude = Math.sqrt(magnitudeSquared(amplitude));
    if (probabilityAmplitude < 1e-10) return;
    const bits = indexToBitString(index, state.qubitCount);
    parts.push(`${formatAmplitude(amplitude, digits)}|${bits}⟩`);
  });
  return parts.length > 0 ? parts.join(" + ") : "0";
}

export function indexToBitString(index: number, qubitCount: number): string {
  return Array.from({ length: qubitCount }, (_, wire) =>
    ((index >> (qubitCount - wire - 1)) & 1).toString()).join("");
}

export function bitStringToIndex(bits: string): number {
  return Number.parseInt(bits, 2);
}

export function stateCloseTo(
  state: QuantumState,
  expected: QuantumState,
  tolerance = 1e-8,
  globalPhaseInvariant = true,
): boolean {
  if (state.qubitCount !== expected.qubitCount) return false;
  if (state.amplitudes.length !== expected.amplitudes.length) return false;
  if (!globalPhaseInvariant) {
    return state.amplitudes.every((amp, index) => {
      const other = expected.amplitudes[index];
      return Math.abs(amp.re - other.re) <= tolerance &&
        Math.abs(amp.im - other.im) <= tolerance;
    });
  }
  const pivot = state.amplitudes.findIndex((amp) =>
    Math.abs(amp.re) > tolerance || Math.abs(amp.im) > tolerance);
  if (pivot < 0) return false;
  const a = state.amplitudes[pivot];
  const b = expected.amplitudes[pivot];
  const aMagnitude = Math.hypot(a.re, a.im);
  const bMagnitude = Math.hypot(b.re, b.im);
  if (Math.abs(aMagnitude - bMagnitude) > tolerance) return false;
  const phaseFactor = complex(
    (a.re * b.re + a.im * b.im) / (aMagnitude * aMagnitude),
    (a.im * b.re - a.re * b.im) / (aMagnitude * aMagnitude),
  );
  return state.amplitudes.every((amp, index) => {
    const expectedAmp = expected.amplitudes[index];
    const inversePhase = { re: phaseFactor.re, im: -phaseFactor.im };
    const rotated = {
      re: amp.re * inversePhase.re - amp.im * inversePhase.im,
      im: amp.re * inversePhase.im + amp.im * inversePhase.re,
    };
    return Math.abs(rotated.re - expectedAmp.re) <= tolerance &&
      Math.abs(rotated.im - expectedAmp.im) <= tolerance;
  });
}

function validateWire(state: QuantumState, wire: number): void {
  if (!Number.isInteger(wire) || wire < 0 || wire >= state.qubitCount) {
    throw new Error(`Qubit index ${wire} is outside this ${state.qubitCount}-qubit circuit.`);
  }
}

function validateDistinctWires(state: QuantumState, first: number, second: number): void {
  validateWire(state, first);
  validateWire(state, second);
  if (first === second) throw new Error("A two-qubit gate needs two different wires.");
}

function formatAmplitude(value: Complex, digits: number): string {
  const round = (number: number) => Number(number.toFixed(digits));
  const real = round(value.re);
  const imaginary = round(value.im);
  if (Math.abs(imaginary) < 1e-10) return `${real}`;
  if (Math.abs(real) < 1e-10) return `${imaginary}i`;
  return `${real}${imaginary < 0 ? "" : "+"}${imaginary}i`;
}

export function isNormalized(state: QuantumState, tolerance = 1e-9): boolean {
  return Math.abs(stateNorm(state) - 1) <= tolerance;
}

export function zeroAmplitudeCount(state: QuantumState, tolerance = 1e-9): number {
  return state.amplitudes.filter((amp) => Math.hypot(amp.re, amp.im) <= tolerance).length;
}

export function addStates(
  left: QuantumState,
  right: QuantumState,
): QuantumState {
  if (left.qubitCount !== right.qubitCount) {
    throw new Error("Cannot add state vectors of different sizes.");
  }
  return {
    qubitCount: left.qubitCount,
    amplitudes: left.amplitudes.map((amp, index) => add(amp, right.amplitudes[index] ?? ZERO)),
  };
}
