import { complex, magnitudeSquared } from "./complex";
import type { QuantumState } from "./stateVector";
import { validateQubitCount } from "./stateVector";

export interface MeasurementResult {
  qubit: number;
  outcome: 0 | 1;
  probability: number;
  probabilitiesBefore: { zero: number; one: number };
  stateAfter: QuantumState;
}

export function measureQubit(
  state: QuantumState,
  qubit: number,
  random: () => number = Math.random,
): MeasurementResult {
  validateQubitCount(state.qubitCount);
  if (!Number.isInteger(qubit) || qubit < 0 || qubit >= state.qubitCount) {
    throw new Error("Cannot measure a qubit outside the circuit.");
  }
  const bit = 2 ** qubit;
  let pZero = 0;
  let pOne = 0;
  state.amplitudes.forEach((amplitude, index) => {
    if ((index & bit) === 0) pZero += magnitudeSquared(amplitude);
    else pOne += magnitudeSquared(amplitude);
  });
  const total = pZero + pOne;
  if (Math.abs(total - 1) > 1e-7) {
    throw new Error(`Cannot measure an unnormalized state (norm squared ${total}).`);
  }
  const draw = Math.min(Math.max(random(), 0), 1 - Number.EPSILON);
  const outcome: 0 | 1 = draw < pZero ? 0 : 1;
  const selectedProbability = outcome === 0 ? pZero : pOne;
  if (selectedProbability <= 0) {
    throw new Error("The random source selected an impossible measurement outcome.");
  }
  const collapsed = state.amplitudes.map((amplitude, index) => {
    const matches = ((index & bit) === 0) === (outcome === 0);
    return matches
      ? complex(amplitude.re / Math.sqrt(selectedProbability), amplitude.im / Math.sqrt(selectedProbability))
      : complex(0);
  });
  return {
    qubit,
    outcome,
    probability: selectedProbability,
    probabilitiesBefore: { zero: pZero, one: pOne },
    stateAfter: { qubitCount: state.qubitCount, amplitudes: collapsed },
  };
}

export function sampleMeasurements(
  state: QuantumState,
  shots: number,
  random: () => number = Math.random,
): Record<string, number> {
  if (!Number.isInteger(shots) || shots < 1 || shots > 100_000) {
    throw new Error("Shots must be an integer from 1 to 100,000.");
  }
  const counts: Record<string, number> = {};
  for (let shot = 0; shot < shots; shot += 1) {
    let current = state;
    let bits = "";
    for (let qubit = state.qubitCount - 1; qubit >= 0; qubit -= 1) {
      const result = measureQubit(current, qubit, random);
      current = result.stateAfter;
      bits += result.outcome;
    }
    counts[bits] = (counts[bits] ?? 0) + 1;
  }
  return counts;
}
