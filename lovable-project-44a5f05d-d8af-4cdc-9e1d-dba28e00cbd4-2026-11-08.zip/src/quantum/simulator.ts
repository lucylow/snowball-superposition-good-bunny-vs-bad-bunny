import { getGateMatrix } from "./gates";
import type { Circuit, GateOperation } from "./circuit";
import {
  applyCNOT,
  applyCZ,
  applySingleQubitMatrix,
  applySWAP,
  cloneState,
  zeroState,
  type QuantumState,
} from "./stateVector";
import { measureQubit, type MeasurementResult } from "./measurement";

export interface CircuitExecution {
  finalState: QuantumState;
  measurements: MeasurementResult[];
  gateCount: number;
  skippedMeasurements: number;
}

export interface SimulationOptions {
  random?: () => number;
  skipMeasurements?: boolean;
}

export function applyOperation(
  state: QuantumState,
  operation: GateOperation,
  options: SimulationOptions = {},
): { state: QuantumState; measurement?: MeasurementResult } {
  switch (operation.kind) {
    case "CNOT":
      return { state: applyCNOT(state, operation.control!, operation.target) };
    case "CZ":
      return { state: applyCZ(state, operation.control!, operation.target) };
    case "SWAP":
      return { state: applySWAP(state, operation.control!, operation.target) };
    case "MEASURE": {
      if (options.skipMeasurements) return { state: cloneState(state) };
      const measurement = measureQubit(state, operation.target, options.random ?? Math.random);
      return { state: measurement.stateAfter, measurement };
    }
    case "H": case "X": case "Y": case "Z": case "S": case "T":
    case "RX": case "RY": case "RZ":
      return {
        state: applySingleQubitMatrix(
          state,
          operation.target,
          getGateMatrix(operation.kind, operation.theta),
        ),
      };
  }
}

export function runCircuit(
  circuit: Circuit,
  options: SimulationOptions = {},
): CircuitExecution {
  let state = zeroState(circuit.qubitCount);
  const measurements: MeasurementResult[] = [];
  let skippedMeasurements = 0;
  for (const operation of circuit.operations) {
    const result = applyOperation(state, operation, options);
    state = result.state;
    if (result.measurement) measurements.push(result.measurement);
    if (operation.kind === "MEASURE" && !result.measurement) skippedMeasurements += 1;
  }
  return {
    finalState: state,
    measurements,
    gateCount: circuit.operations.length,
    skippedMeasurements,
  };
}

/** Run a circuit up to (but not including) a selected operation. */
export function runCircuitPrefix(
  circuit: Circuit,
  operationIndex: number,
): QuantumState {
  let state = zeroState(circuit.qubitCount);
  circuit.operations.slice(0, operationIndex).forEach((operation) => {
    state = applyOperation(state, operation, { skipMeasurements: true }).state;
  });
  return state;
}

export function simulateUnitaryCircuit(circuit: Circuit): QuantumState {
  const execution = runCircuit(circuit, { skipMeasurements: true });
  return execution.finalState;
}
