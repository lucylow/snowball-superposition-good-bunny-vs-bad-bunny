/** Minimal complex-number utilities used by the educational state-vector simulator. */
export interface Complex {
  re: number;
  im: number;
}

export const ZERO: Complex = Object.freeze({ re: 0, im: 0 });
export const ONE: Complex = Object.freeze({ re: 1, im: 0 });
export const I: Complex = Object.freeze({ re: 0, im: 1 });

export function complex(re = 0, im = 0): Complex {
  return { re, im };
}

export function add(a: Complex, b: Complex): Complex {
  return { re: a.re + b.re, im: a.im + b.im };
}

export function subtract(a: Complex, b: Complex): Complex {
  return { re: a.re - b.re, im: a.im - b.im };
}

export function multiply(a: Complex, b: Complex): Complex {
  return {
    re: a.re * b.re - a.im * b.im,
    im: a.re * b.im + a.im * b.re,
  };
}

export function scale(a: Complex, scalar: number): Complex {
  return { re: a.re * scalar, im: a.im * scalar };
}

export function conjugate(a: Complex): Complex {
  return { re: a.re, im: -a.im };
}

export function magnitudeSquared(a: Complex): number {
  return a.re * a.re + a.im * a.im;
}

export function magnitude(a: Complex): number {
  return Math.sqrt(magnitudeSquared(a));
}

export function phase(a: Complex): number {
  return Math.atan2(a.im, a.re);
}

export function polar(radius: number, angle: number): Complex {
  return {
    re: radius * Math.cos(angle),
    im: radius * Math.sin(angle),
  };
}

export function divide(a: Complex, b: Complex): Complex {
  const denominator = magnitudeSquared(b);
  if (denominator === 0) {
    throw new Error("Cannot divide by a zero complex number.");
  }
  return multiply(a, scale(conjugate(b), 1 / denominator));
}

export function approximatelyEqual(
  a: Complex,
  b: Complex,
  tolerance = 1e-9,
): boolean {
  return (
    Math.abs(a.re - b.re) <= tolerance &&
    Math.abs(a.im - b.im) <= tolerance
  );
}

export function formatComplex(value: Complex, digits = 3): string {
  const re = cleanNumber(value.re, digits);
  const im = cleanNumber(Math.abs(value.im), digits);
  if (im === 0) return `${re}`;
  const imaginary = `${im}i`;
  if (re === 0) return value.im < 0 ? `-${imaginary}` : imaginary;
  return `${re} ${value.im < 0 ? "-" : "+"} ${imaginary}`;
}

export function cleanNumber(value: number, digits = 3): number {
  const rounded = Number(value.toFixed(digits));
  return Object.is(rounded, -0) ? 0 : rounded;
}
