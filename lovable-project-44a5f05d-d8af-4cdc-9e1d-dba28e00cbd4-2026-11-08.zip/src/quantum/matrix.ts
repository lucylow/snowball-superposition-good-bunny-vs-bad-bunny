import {
  add,
  complex,
  multiply,
  scale,
  type Complex,
} from "./complex";

/** A 2 x 2 matrix, represented in row-major order. */
export type Matrix2 = readonly [
  readonly [Complex, Complex],
  readonly [Complex, Complex],
];

export function matrix2(
  a00: Complex,
  a01: Complex,
  a10: Complex,
  a11: Complex,
): Matrix2 {
  return [
    [a00, a01],
    [a10, a11],
  ];
}

export function multiplyMatrixVector(
  matrix: Matrix2,
  vector: readonly [Complex, Complex],
): [Complex, Complex] {
  return [
    add(multiply(matrix[0][0], vector[0]), multiply(matrix[0][1], vector[1])),
    add(multiply(matrix[1][0], vector[0]), multiply(matrix[1][1], vector[1])),
  ];
}

export function multiplyMatrices(left: Matrix2, right: Matrix2): Matrix2 {
  const entry = (row: 0 | 1, col: 0 | 1): Complex =>
    add(
      multiply(left[row][0], right[0][col]),
      multiply(left[row][1], right[1][col]),
    );
  return matrix2(entry(0, 0), entry(0, 1), entry(1, 0), entry(1, 1));
}

export function identityMatrix(): Matrix2 {
  return matrix2(complex(1), complex(0), complex(0), complex(1));
}

export function rotationX(theta: number): Matrix2 {
  const cosine = Math.cos(theta / 2);
  const sine = Math.sin(theta / 2);
  return matrix2(
    complex(cosine),
    complex(0, -sine),
    complex(0, -sine),
    complex(cosine),
  );
}

export function rotationY(theta: number): Matrix2 {
  const cosine = Math.cos(theta / 2);
  const sine = Math.sin(theta / 2);
  return matrix2(
    complex(cosine),
    complex(-sine),
    complex(sine),
    complex(cosine),
  );
}

export function rotationZ(theta: number): Matrix2 {
  const cosine = Math.cos(theta / 2);
  const sine = Math.sin(theta / 2);
  return matrix2(
    complex(cosine, -sine),
    complex(0),
    complex(0),
    complex(cosine, sine),
  );
}

export function matrixScale(matrix: Matrix2, factor: number): Matrix2 {
  return matrix2(
    scale(matrix[0][0], factor),
    scale(matrix[0][1], factor),
    scale(matrix[1][0], factor),
    scale(matrix[1][1], factor),
  );
}
