// @ts-nocheck
import { complex, magnitudeSquared } from "./complex";
import type { QuantumState } from "./stateVector";

export interface BlochVector {
  x: number;
  y: number;
  z: number;
  radius: number;
  purity: number;
  entropyBits: number;
}

/**
 * Calculate the reduced single-qubit Bloch vector for one wire of a pure
 * multi-qubit state. Other qubits are traced out, so entangled qubits can
 * have a mixed reduced state and a Bloch-vector radius below one.
 */
export function getBlochVector(state: QuantumState, qubit: number): BlochVector {
  if (!Number.isInteger(qubit) || qubit < 0 || qubit >= state.qubitCount) {
    throw new Error("Bloch-vector wire is outside this circuit.");
  }
  const bit = 2 ** qubit;
  let pZero = 0;
  let pOne = 0;
  let offDiagonal = complex(0);

  for (let index = 0; index < state.amplitudes.length; index += 1) {
    const amplitude = state.amplitudes[index];
    if ((index & bit) === 0) {
      pZero += magnitudeSquared(amplitude);
      const partner = state.amplitudes[index | bit];
      offDiagonal.re += amplitude.re * partner.re + amplitude.im * partner.im;
      offDiagonal.im += amplitude.im * partner.re - amplitude.re * partner.im;
    } else {
      pOne += magnitudeSquared(amplitude);
    }
  }

  const x = 2 * offDiagonal.re;
  const y = -2 * offDiagonal.im;
  const z = pZero - pOne;
  const radius = Math.min(1, Math.sqrt(x * x + y * y + z * z));
  const purity = (1 + radius * radius) / 2;
  const eigenvalueHigh = (1 + radius) / 2;
  const entropyBits = binaryEntropy(eigenvalueHigh);

  return { x, y, z, radius, purity, entropyBits };
}

export function binaryEntropy(probability: number): number {
  if (probability <= 0 || probability >= 1) return 0;
  return -probability * Math.log2(probability) -
    (1 - probability) * Math.log2(1 - probability);
}

export function formatBlochCoordinate(value: number, digits = 2): string {
  const rounded = Number(value.toFixed(digits));
  return Object.is(rounded, -0) ? "0" : rounded.toFixed(digits);
}

export function isPureReducedQubit(vector: BlochVector, tolerance = 1e-8): boolean {
  return Math.abs(vector.purity - 1) <= tolerance;
}
