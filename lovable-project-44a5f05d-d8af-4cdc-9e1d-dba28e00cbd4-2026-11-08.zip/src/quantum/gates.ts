import { complex, polar, type Complex } from "./complex";
import { matrix2, rotationX, rotationY, rotationZ, type Matrix2 } from "./matrix";

export type GateKind =
  | "H"
  | "X"
  | "Y"
  | "Z"
  | "S"
  | "T"
  | "RX"
  | "RY"
  | "RZ"
  | "CNOT"
  | "CZ"
  | "SWAP"
  | "MEASURE";

export type GateFamily = "foundation" | "phase" | "rotation" | "two-qubit" | "readout";

export interface GateDefinition {
  kind: GateKind;
  label: string;
  name: string;
  family: GateFamily;
  wires: 1 | 2;
  description: string;
  bunnyTip: string;
  matrix?: Matrix2;
}

const rootHalf = 1 / Math.sqrt(2);

export const GATE_DEFINITIONS: Record<GateKind, GateDefinition> = {
  H: {
    kind: "H",
    label: "H",
    name: "Hadamard",
    family: "foundation",
    wires: 1,
    description: "Creates balanced superposition from a computational-basis state.",
    bunnyTip: "A carrot on each path! The bunny now has two possible measurement outcomes.",
    matrix: matrix2(
      complex(rootHalf), complex(rootHalf),
      complex(rootHalf), complex(-rootHalf),
    ),
  },
  X: {
    kind: "X",
    label: "X",
    name: "Pauli-X",
    family: "foundation",
    wires: 1,
    description: "Exchanges |0> and |1>; it is the quantum NOT gate.",
    bunnyTip: "Flip the bunny's Good/Bad label: 0 becomes 1 and 1 becomes 0.",
    matrix: matrix2(complex(0), complex(1), complex(1), complex(0)),
  },
  Y: {
    kind: "Y",
    label: "Y",
    name: "Pauli-Y",
    family: "phase",
    wires: 1,
    description: "Flips the basis state and adds a complex phase.",
    bunnyTip: "A dramatic hop that flips the state and twists its phase.",
    matrix: matrix2(complex(0), complex(0, -1), complex(0, 1), complex(0)),
  },
  Z: {
    kind: "Z",
    label: "Z",
    name: "Pauli-Z",
    family: "phase",
    wires: 1,
    description: "Leaves |0> unchanged and changes the sign of |1>.",
    bunnyTip: "The bunny keeps its label, but the phase of the |1> path changes.",
    matrix: matrix2(complex(1), complex(0), complex(0), complex(-1)),
  },
  S: {
    kind: "S",
    label: "S",
    name: "S gate",
    family: "phase",
    wires: 1,
    description: "Adds a quarter-turn phase to the |1> component.",
    bunnyTip: "A quarter-turn carrot twirl for the |1> amplitude.",
    matrix: matrix2(complex(1), complex(0), complex(0), complex(0, 1)),
  },
  T: {
    kind: "T",
    label: "T",
    name: "T gate",
    family: "phase",
    wires: 1,
    description: "Adds an eighth-turn phase to the |1> component.",
    bunnyTip: "A tiny phase sprinkle. Small twists can change later interference.",
    matrix: matrix2(complex(1), complex(0), complex(0), polar(1, Math.PI / 4)),
  },
  RX: {
    kind: "RX",
    label: "RX",
    name: "X rotation",
    family: "rotation",
    wires: 1,
    description: "Rotates a qubit around the Bloch sphere's X axis.",
    bunnyTip: "Choose an angle and roll the qubit around the X axis.",
  },
  RY: {
    kind: "RY",
    label: "RY",
    name: "Y rotation",
    family: "rotation",
    wires: 1,
    description: "Rotates a qubit around the Bloch sphere's Y axis.",
    bunnyTip: "Choose an angle and roll the qubit around the Y axis.",
  },
  RZ: {
    kind: "RZ",
    label: "RZ",
    name: "Z rotation",
    family: "rotation",
    wires: 1,
    description: "Rotates a qubit around the Bloch sphere's Z axis.",
    bunnyTip: "Turn the qubit around the Z axis without changing basis probabilities directly.",
  },
  CNOT: {
    kind: "CNOT",
    label: "⊕",
    name: "Controlled-X",
    family: "two-qubit",
    wires: 2,
    description: "Flips the target when the control qubit is 1.",
    bunnyTip: "The control bunny checks its bit before the carrot gate flips the target.",
  },
  CZ: {
    kind: "CZ",
    label: "CZ",
    name: "Controlled-Z",
    family: "two-qubit",
    wires: 2,
    description: "Adds a minus sign only to the |11> component.",
    bunnyTip: "Only the both-1 carrot basket receives a phase stamp.",
  },
  SWAP: {
    kind: "SWAP",
    label: "×",
    name: "SWAP",
    family: "two-qubit",
    wires: 2,
    description: "Exchanges the states of two qubits.",
    bunnyTip: "The two bunny baskets trade places.",
  },
  MEASURE: {
    kind: "MEASURE",
    label: "M",
    name: "Measurement",
    family: "readout",
    wires: 1,
    description: "Samples an outcome and collapses the measured qubit.",
    bunnyTip: "Open the carrot box to reveal one outcome from the probability distribution.",
  },
};

export function getGateMatrix(kind: GateKind, theta = Math.PI / 2): Matrix2 {
  switch (kind) {
    case "RX": return rotationX(theta);
    case "RY": return rotationY(theta);
    case "RZ": return rotationZ(theta);
    case "H": case "X": case "Y": case "Z": case "S": case "T": {
      const matrix = GATE_DEFINITIONS[kind].matrix;
      if (!matrix) throw new Error(`Gate ${kind} does not define a matrix.`);
      return matrix;
    }
    case "CNOT": case "CZ": case "SWAP": case "MEASURE":
      throw new Error(`${kind} is not a single-qubit matrix gate.`);
  }
}

export function gateParameterLabel(kind: GateKind, theta?: number): string {
  if (kind !== "RX" && kind !== "RY" && kind !== "RZ") return "";
  const angle = theta ?? Math.PI / 2;
  const degrees = Math.round((angle * 180) / Math.PI);
  return `${kind}(${degrees}°)`;
}
