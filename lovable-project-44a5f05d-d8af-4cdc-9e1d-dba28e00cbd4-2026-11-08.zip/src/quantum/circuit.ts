// @ts-nocheck
import type { GateKind } from "./gates";

export interface GateOperation {
  id: string;
  kind: GateKind;
  target: number;
  control?: number;
  theta?: number;
  label?: string;
}

export interface Circuit {
  qubitCount: number;
  operations: GateOperation[];
}

export function createCircuit(qubitCount = 1): Circuit {
  validateCircuitQubits(qubitCount);
  return { qubitCount, operations: [] };
}

export function createOperation(
  kind: GateKind,
  target: number,
  options: { control?: number; theta?: number; id?: string; label?: string } = {},
): GateOperation {
  return {
    id: options.id ?? createOperationId(),
    kind,
    target,
    control: options.control,
    theta: options.theta,
    label: options.label,
  };
}

export function appendOperation(circuit: Circuit, operation: GateOperation): Circuit {
  validateOperation(circuit.qubitCount, operation);
  return { ...circuit, operations: [...circuit.operations, operation] };
}

export function removeOperation(circuit: Circuit, operationId: string): Circuit {
  return {
    ...circuit,
    operations: circuit.operations.filter((operation) => operation.id !== operationId),
  };
}

export function moveOperation(
  circuit: Circuit,
  operationId: string,
  destinationIndex: number,
): Circuit {
  const currentIndex = circuit.operations.findIndex((operation) => operation.id === operationId);
  if (currentIndex < 0) return circuit;
  if (!Number.isInteger(destinationIndex) || destinationIndex < 0 || destinationIndex >= circuit.operations.length) {
    throw new Error("The destination slot is outside the circuit.");
  }
  const operations = [...circuit.operations];
  const [operation] = operations.splice(currentIndex, 1);
  operations.splice(destinationIndex, 0, operation);
  return { ...circuit, operations };
}

export function clearCircuit(circuit: Circuit): Circuit {
  return { ...circuit, operations: [] };
}

export function validateCircuitQubits(qubitCount: number): void {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 8) {
    throw new Error("Choose between 1 and 8 qubit wires.");
  }
}

export function validateOperation(qubitCount: number, operation: GateOperation): void {
  if (!operation.id.trim()) throw new Error("Every gate operation needs an id.");
  if (!Number.isInteger(operation.target) || operation.target < 0 || operation.target >= qubitCount) {
    throw new Error(`Target wire ${operation.target} does not exist.`);
  }
  const twoQubit = operation.kind === "CNOT" || operation.kind === "CZ" || operation.kind === "SWAP";
  if (twoQubit) {
    if (operation.control === undefined || !Number.isInteger(operation.control)) {
      throw new Error(`${operation.kind} needs a second wire.`);
    }
    if (operation.control < 0 || operation.control >= qubitCount || operation.control === operation.target) {
      throw new Error(`${operation.kind} needs two distinct wires in this circuit.`);
    }
  }
  if ((operation.kind === "RX" || operation.kind === "RY" || operation.kind === "RZ") &&
      !Number.isFinite(operation.theta ?? Math.PI / 2)) {
    throw new Error(`${operation.kind} needs a finite rotation angle.`);
  }
}

function createOperationId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `gate-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
