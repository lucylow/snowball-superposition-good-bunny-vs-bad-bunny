import type { GateKind } from "../quantum/gates";

export type MissionDifficulty = "starter" | "easy" | "medium" | "advanced";
export type MissionCategory = "qubits" | "single-gate" | "phase" | "measurement" | "entanglement" | "circuits";

export interface MissionOperation {
  kind: GateKind;
  target: number;
  control?: number;
  theta?: number;
}

export interface Mission {
  id: string;
  number: number;
  chapter: string;
  title: string;
  subtitle: string;
  difficulty: MissionDifficulty;
  category: MissionCategory;
  carrotReward: number;
  qubitCount: number;
  story: string;
  objective: string;
  lesson: string;
  hint: string;
  targetCircuit: MissionOperation[];
  successMessage: string;
  unlocks: string[];
}

export interface PlayerProgress {
  completedMissionIds: string[];
  carrotCount: number;
  bestCircuitLengths: Record<string, number>;
  learnedGateKinds: GateKind[];
  lastPlayedAt: string | null;
  soundEnabled: boolean;
}

export interface MissionResult {
  missionId: string;
  completed: boolean;
  score: number;
  carrotsEarned: number;
  completedAt: string;
}
