import type { GateKind } from "../quantum/gates";
import type { PlayerProgress } from "./types";

export const PROGRESS_STORAGE_KEY = "good-bunny-quantum-showdown:v1";

export const DEFAULT_PROGRESS: PlayerProgress = {
  completedMissionIds: [],
  carrotCount: 0,
  bestCircuitLengths: {},
  learnedGateKinds: [],
  lastPlayedAt: null,
  soundEnabled: true,
};

const VALID_GATES: GateKind[] = [
  "H", "X", "Y", "Z", "S", "T", "RX", "RY", "RZ",
  "CNOT", "CZ", "SWAP", "MEASURE",
];

export function loadProgress(storage?: Storage): PlayerProgress {
  try {
    const targetStorage = storage ?? window.localStorage;
    const raw = targetStorage.getItem(PROGRESS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_PROGRESS };
    return normalizeProgress(JSON.parse(raw) as Partial<PlayerProgress>);
  } catch {
    return { ...DEFAULT_PROGRESS };
  }
}

export function saveProgress(
  progress: PlayerProgress,
  storage?: Storage,
): void {
  const targetStorage = storage ?? window.localStorage;
  targetStorage.setItem(PROGRESS_STORAGE_KEY, JSON.stringify(progress));
}

export function normalizeProgress(raw: Partial<PlayerProgress>): PlayerProgress {
  return {
    completedMissionIds: Array.isArray(raw.completedMissionIds)
      ? raw.completedMissionIds.filter((id): id is string => typeof id === "string")
      : [],
    carrotCount: Number.isFinite(raw.carrotCount) && (raw.carrotCount ?? 0) >= 0
      ? Math.floor(raw.carrotCount!)
      : 0,
    bestCircuitLengths: normalizeRecord(raw.bestCircuitLengths),
    learnedGateKinds: Array.isArray(raw.learnedGateKinds)
      ? raw.learnedGateKinds.filter((gate): gate is GateKind => VALID_GATES.includes(gate as GateKind))
      : [],
    lastPlayedAt: typeof raw.lastPlayedAt === "string" ? raw.lastPlayedAt : null,
    soundEnabled: typeof raw.soundEnabled === "boolean" ? raw.soundEnabled : true,
  };
}

export function completeMission(
  current: PlayerProgress,
  missionId: string,
  reward: number,
  circuitLength: number,
  learnedGates: GateKind[],
): PlayerProgress {
  const alreadyCompleted = current.completedMissionIds.includes(missionId);
  const oldBest = current.bestCircuitLengths[missionId];
  const bestCircuitLengths = {
    ...current.bestCircuitLengths,
    [missionId]: oldBest === undefined ? circuitLength : Math.min(oldBest, circuitLength),
  };
  return {
    ...current,
    completedMissionIds: alreadyCompleted
      ? current.completedMissionIds
      : [...current.completedMissionIds, missionId],
    carrotCount: alreadyCompleted ? current.carrotCount : current.carrotCount + reward,
    bestCircuitLengths,
    learnedGateKinds: [...new Set([...current.learnedGateKinds, ...learnedGates])],
    lastPlayedAt: new Date().toISOString(),
  };
}

function normalizeRecord(value: unknown): Record<string, number> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return Object.fromEntries(
    Object.entries(value).filter((entry): entry is [string, number] =>
      typeof entry[0] === "string" && Number.isInteger(entry[1]) && (entry[1] as number) >= 0),
  );
}
