// @ts-nocheck
import { createCircuit, createOperation } from "../quantum/circuit";
import { runCircuit } from "../quantum/simulator";
import { stateCloseTo } from "../quantum/stateVector";
import type { Circuit } from "../quantum/circuit";
import type { Mission } from "./types";

export interface MissionEvaluation {
  passed: boolean;
  stateMatches: boolean;
  measurementPresent: boolean;
  expectedDescription: string;
  message: string;
}

export function evaluateMission(circuit: Circuit, mission: Mission): MissionEvaluation {
  if (circuit.qubitCount !== mission.qubitCount) {
    return {
      passed: false,
      stateMatches: false,
      measurementPresent: false,
      expectedDescription: "Use the number of wires requested by this mission.",
      message: `This mission needs ${mission.qubitCount} qubit wire(s).`,
    };
  }
  const targetCircuit = createCircuit(mission.qubitCount);
  mission.targetCircuit.forEach((step, index) => {
    targetCircuit.operations.push(createOperation(step.kind, step.target, {
      control: step.control,
      theta: step.theta,
      id: `target-${mission.id}-${index}`,
    }));
  });
  const expected = runCircuit(targetCircuit, { skipMeasurements: true }).finalState;
  const actual = runCircuit(circuit, { skipMeasurements: true }).finalState;
  const stateMatches = stateCloseTo(actual, expected, 1e-7, true);
  const needsMeasurement = mission.targetCircuit.some((step) => step.kind === "MEASURE");
  const measurementPresent = !needsMeasurement || circuit.operations.some((operation) => operation.kind === "MEASURE");
  const passed = stateMatches && measurementPresent;
  let message = "Not quite yet. Compare the state display with the mission target and adjust your circuit.";
  if (stateMatches && needsMeasurement && !measurementPresent) {
    message = "Your state is prepared! Now add a measurement gate and run the circuit.";
  } else if (passed) {
    message = mission.successMessage;
  }
  return {
    passed,
    stateMatches,
    measurementPresent,
    expectedDescription: expected.amplitudes
      .map((amplitude, index) => ({ amplitude, index }))
      .filter(({ amplitude }) => Math.hypot(amplitude.re, amplitude.im) > 1e-8)
      .map(({ index }) => `|${index.toString(2).padStart(mission.qubitCount, "0")}>`)
      .join(" + "),
    message,
  };
}
