import type { PlayerProgress } from "./types";

export const CARROTS_PER_LEVEL = 50;

export function getLevel(carrots: number) {
  const level = Math.floor(carrots / CARROTS_PER_LEVEL) + 1;
  const into = carrots % CARROTS_PER_LEVEL;
  return { level, into, needed: CARROTS_PER_LEVEL, pct: Math.round((into / CARROTS_PER_LEVEL) * 100) };
}

export const RANKS = ["Curious Kit", "Qubit Hopper", "Gate Gardener", "Phase Ranger", "Entangle Bun", "Quantum Warren Master"];
export const getRank = (level: number) => RANKS[Math.min(level - 1, RANKS.length - 1)];

export interface Badge { id: string; icon: string; name: string; desc: string; earned: boolean }

export function getBadges(p: PlayerProgress, totalMissions: number): Badge[] {
  const done = p.completedMissionIds.length;
  const gates = p.learnedGateKinds;
  return [
    { id: "first", icon: "🌱", name: "First Sprout", desc: "Complete 1 mission", earned: done >= 1 },
    { id: "five", icon: "🥕", name: "Carrot Collector", desc: "Complete 5 missions", earned: done >= 5 },
    { id: "super", icon: "🌀", name: "Superposer", desc: "Learn the H gate", earned: gates.includes("H") },
    { id: "entangle", icon: "🔗", name: "Entangler", desc: "Learn CNOT", earned: gates.includes("CNOT") },
    { id: "toolbox", icon: "🧰", name: "Gate Toolbox", desc: "Learn 8 different gates", earned: gates.length >= 8 },
    { id: "all", icon: "👑", name: "Warren Champion", desc: "Complete every mission", earned: totalMissions > 0 && done >= totalMissions },
  ];
}
