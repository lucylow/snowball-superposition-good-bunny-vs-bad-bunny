import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { suggestChallenge } from "@/lib/challenge.functions";
import type { Mission, PlayerProgress } from "@/game/types";

export default function NextChallenge({ mission, circuit, progress, total }: { mission: Mission; circuit: string; progress: PlayerProgress; total: number }) {
  const run = useServerFn(suggestChallenge);
  const [note, setNote] = useState("");
  const [out, setOut] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const go = async () => {
    setBusy(true); setErr(null);
    try {
      const r = await run({ data: {
        mission: mission.title, objective: mission.objective, circuit,
        completed: progress.completedMissionIds.length, total, carrots: progress.carrotCount,
        gates: progress.learnedGateKinds.join(", "), note,
      } });
      if (r.error) setErr(r.error); else setOut(r.challenge);
    } catch { setErr("Good Bunny couldn't dream up a challenge right now. Please try again."); }
    finally { setBusy(false); }
  };

  return (
    <section className="learning-panel" style={{ marginTop: 16 }}>
      <h3>✨ My next challenge</h3>
      <p style={{ margin: "4px 0 8px" }}>Good Bunny looks at your mission, circuit and progress to invent a challenge just for you.</p>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={300}
          placeholder="Optional: what do you want to practice?" style={{ flex: 1, minWidth: 200, padding: 8, borderRadius: 8, border: "1px solid currentColor" }} />
        <button type="button" onClick={go} disabled={busy}>{busy ? "Inventing…" : out ? "Another one" : "Suggest a challenge"}</button>
      </div>
      {out && <p style={{ marginTop: 10, whiteSpace: "pre-line" }}>{out}</p>}
      {err && <p key={err} role="alert" className="inline-error" style={{ marginTop: 10 }}>{err}</p>}
    </section>
  );
}
