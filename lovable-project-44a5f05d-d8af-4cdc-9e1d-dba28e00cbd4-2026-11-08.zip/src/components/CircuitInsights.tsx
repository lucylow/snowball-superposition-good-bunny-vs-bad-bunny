import { useState } from "react";
import type { Circuit, GateOperation } from "../quantum/circuit";
import type { GateKind } from "../quantum/gates";

const GATE_NOTES: Record<GateKind, { matrix: string; note: string }> = {
  H: { matrix: "1/√2 [[1,1],[1,−1]]", note: "Creates an equal superposition. |0> → (|0>+|1>)/√2." },
  X: { matrix: "[[0,1],[1,0]]", note: "Bit flip. Swaps the amplitudes of |0> and |1>." },
  Y: { matrix: "[[0,−i],[i,0]]", note: "Bit flip plus a phase of i. A half-turn around the Y axis." },
  Z: { matrix: "[[1,0],[0,−1]]", note: "Phase flip. Puts a minus sign on |1>; odds stay the same." },
  S: { matrix: "[[1,0],[0,i]]", note: "Quarter-turn phase. Two S gates equal one Z." },
  T: { matrix: "[[1,0],[0,e^{iπ/4}]]", note: "Eighth-turn phase. Key for universal fault-tolerant circuits." },
  RX: { matrix: "e^{−iθX/2}", note: "Rotates around the X axis by θ on the Bloch sphere." },
  RY: { matrix: "e^{−iθY/2}", note: "Rotates around Y. Sets P(1) = sin²(θ/2) from |0>." },
  RZ: { matrix: "e^{−iθZ/2}", note: "Rotates around Z. Changes phase only, not odds." },
  CNOT: { matrix: "|0⟩⟨0|⊗I + |1⟩⟨1|⊗X", note: "Flips the target only when the control is 1. Makes entanglement." },
  CZ: { matrix: "diag(1,1,1,−1)", note: "Adds a minus sign only to |11>. Symmetric in both qubits." },
  SWAP: { matrix: "3 CNOTs", note: "Exchanges the states of two qubits." },
  MEASURE: { matrix: "P(k) = |αₖ|²", note: "Reads out 0 or 1 and collapses the qubit." },
};

const TWO = new Set<GateKind>(["CNOT", "CZ", "SWAP"]);

function depth(circuit: Circuit) {
  const layer = Array<number>(circuit.qubitCount).fill(0);
  for (const op of circuit.operations) {
    const wires = op.control !== undefined ? [op.target, op.control] : [op.target];
    const next = Math.max(...wires.map((w) => layer[w] ?? 0)) + 1;
    wires.forEach((w) => (layer[w] = next));
  }
  return Math.max(0, ...layer);
}

function describe(op: GateOperation) {
  const where = op.control !== undefined ? `q${op.control} → q${op.target}` : `q${op.target}`;
  const angle = op.theta !== undefined ? ` (θ = ${Math.round((op.theta * 180) / Math.PI)}°)` : "";
  return `${op.kind} on ${where}${angle}`;
}

export function CircuitInsights({ circuit }: { circuit: Circuit }) {
  const [open, setOpen] = useState(true);
  const ops = circuit.operations;
  const entangling = ops.filter((o) => TWO.has(o.kind)).length;
  return (
    <section className="edu-section circuit-insights" aria-label="Circuit insights">
      <button type="button" className="insights-toggle" onClick={() => setOpen((v) => !v)} aria-expanded={open}>
        <span className="eyebrow">CIRCUIT X-RAY</span>
        <span>{open ? "Hide" : "Show"}</span>
      </button>
      {open && (
        <>
          <div className="insights-stats">
            <div><strong>{ops.length}</strong><span>gates</span></div>
            <div><strong>{depth(circuit)}</strong><span>depth</span></div>
            <div><strong>{entangling}</strong><span>2-qubit gates</span></div>
            <div><strong>{2 ** circuit.qubitCount}</strong><span>basis states</span></div>
          </div>
          <p className="insights-tip">
            Read circuits left to right: time flows along each wire. Depth counts layers of gates that can run at the same time.
          </p>
          {ops.length === 0 ? (
            <p className="empty-wire-hint">Add a gate and the bunny will explain each step here.</p>
          ) : (
            <ol className="insights-steps">
              {ops.map((op, i) => {
                const g = GATE_NOTES[op.kind];
                return (
                  <li key={op.id} style={{ animationDelay: `${i * 40}ms` }}>
                    <span className="insights-step-n">{i + 1}</span>
                    <div>
                      <strong>{describe(op)}</strong>
                      <code>{g.matrix}</code>
                      <p>{g.note}</p>
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </>
      )}
    </section>
  );
}

const FAMOUS = [
  { name: "Bell pair", gates: ["H q0", "CNOT q0→q1"], result: "(|00> + |11>)/√2", why: "The two qubits always match when measured, even though each alone looks random." },
  { name: "GHZ state", gates: ["H q0", "CNOT q0→q1", "CNOT q1→q2"], result: "(|000> + |111>)/√2", why: "Entanglement spread across three qubits. Measure one and you know them all." },
  { name: "Interference loop", gates: ["H q0", "H q0"], result: "|0>", why: "The paths to |1> cancel. This is the heart of every quantum speed-up." },
  { name: "Phase kickback", gates: ["X q1", "H q0", "H q1", "CNOT q0→q1", "H q0"], result: "q0 = |1>", why: "The target's phase kicks back onto the control. Used in Deutsch–Jozsa and Grover." },
  { name: "Plus/minus check", gates: ["H q0", "Z q0", "H q0"], result: "|1>", why: "H·Z·H = X. A phase flip in one basis is a bit flip in another." },
  { name: "Biased coin", gates: ["RY(60°) q0", "M q0"], result: "P(1) = 25%", why: "sin²(30°) = 0.25. Rotation angles let you tune probabilities." },
];

export function FamousCircuits() {
  return (
    <section className="edu-section">
      <span className="eyebrow">CIRCUIT RECIPES</span>
      <h2>Famous circuits to build in the lab</h2>
      <div className="edu-quiz">
        {FAMOUS.map((c) => (
          <article key={c.name} className="edu-question">
            <h3>{c.name}</h3>
            <div className="recipe-gates">
              {c.gates.map((g, i) => (
                <span key={i} className="recipe-gate" style={{ animationDelay: `${i * 80}ms` }}>{g}</span>
              ))}
              <span className="recipe-arrow">→</span>
              <code>{c.result}</code>
            </div>
            <p className="edu-why">{c.why}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
