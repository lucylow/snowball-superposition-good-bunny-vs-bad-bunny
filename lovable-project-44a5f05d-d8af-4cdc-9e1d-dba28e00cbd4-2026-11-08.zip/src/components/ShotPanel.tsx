import { useMemo, useState } from "react";
import { sampleMeasurements } from "../quantum/measurement";
import type { QuantumState } from "../quantum/stateVector";

interface ShotPanelProps {
  state: QuantumState;
}

export default function ShotPanel({ state }: ShotPanelProps) {
  const [shots, setShots] = useState(100);
  const [seed, setSeed] = useState(1);
  const [runVersion, setRunVersion] = useState(0);
  const counts = useMemo(() => {
    if (runVersion === 0) return null;
    let next = seed;
    const random = () => {
      next = (next * 48271) % 2_147_483_647;
      return next / 2_147_483_647;
    };
    return sampleMeasurements(state, shots, random);
  }, [runVersion, seed, shots, state]);

  const maxCount = counts ? Math.max(...Object.values(counts), 1) : 1;

  return (
    <section className="shot-panel">
      <div className="shot-panel__heading">
        <div>
          <span className="eyebrow">REPEATED EXPERIMENTS</span>
          <h3>Carrot shot counter</h3>
        </div>
        <span className="shot-icon">📊</span>
      </div>
      <p>Take many measurements to estimate the probability distribution. Each shot is one experiment.</p>
      <div className="shot-controls">
        <label htmlFor="shot-count">Number of shots</label>
        <select id="shot-count" value={shots} onChange={(event) => setShots(Number(event.target.value))}>
          <option value={10}>10 shots</option>
          <option value={100}>100 shots</option>
          <option value={500}>500 shots</option>
          <option value={1000}>1,000 shots</option>
        </select>
        <button type="button" className="button button--small" onClick={() => { setSeed((value) => value + 1); setRunVersion((value) => value + 1); }}>
          Run shots
        </button>
      </div>
      {counts ? (
        <div className="shot-results" aria-live="polite">
          {Object.entries(counts).sort(([left], [right]) => left.localeCompare(right)).map(([bits, count]) => (
            <div className="shot-result" key={bits}>
              <span className="shot-result__label">|{bits}⟩</span>
              <div className="shot-result__bar"><span style={{ width: `${(count / maxCount) * 100}%` }} /></div>
              <strong>{count}</strong>
              <small>{((count / shots) * 100).toFixed(1)}%</small>
            </div>
          ))}
        </div>
      ) : (
        <div className="shot-empty">Your histogram is waiting for its first carrot-sized experiment.</div>
      )}
      <small className="shot-footnote">This is a local educational simulator. Results are sampled from the state vector; no quantum hardware is contacted.</small>
    </section>
  );
}
