import type { Circuit, GateOperation } from "../quantum/circuit";
import { GATE_DEFINITIONS, gateParameterLabel } from "../quantum/gates";

interface CircuitBoardProps {
  circuit: Circuit;
  onRemove: (id: string) => void;
}

export default function CircuitBoard({ circuit, onRemove }: CircuitBoardProps) {
  return (
    <section className="circuit-board" aria-label="Quantum circuit editor">
      <div className="circuit-board__header">
        <div>
          <span className="eyebrow">YOUR QUANTUM RECIPE</span>
          <h3>Circuit kitchen</h3>
        </div>
        <span className="circuit-count" aria-live="polite">{circuit.operations.length} gate{circuit.operations.length === 1 ? "" : "s"}</span>
      </div>
      <div className="circuit-wires">
        {Array.from({ length: circuit.qubitCount }, (_, wire) => (
          <div className="circuit-wire" key={wire}>
            <div className="circuit-wire__label">
              <span className="wire-dot">q{wire}</span>
              <span className="wire-start">|0⟩</span>
            </div>
            <div className="circuit-wire__track">
              <span className="wire-line" />
              {circuit.operations.map((operation, index) => (
                <GateSlot
                  key={operation.id}
                  operation={operation}
                  wire={wire}
                  index={index}
                  onRemove={onRemove}
                />
              ))}
              {circuit.operations.length === 0 && wire === 0 && (
                <span className="empty-wire-hint">Add a gate from the carrot shelf ↓</span>
              )}
            </div>
          </div>
        ))}
      </div>
      <div className="circuit-board__footer">
        <span>Input: {"|" + "0".repeat(circuit.qubitCount) + "⟩"}</span>
        <span>Wire order: q{circuit.qubitCount - 1} ... q0</span>
      </div>
    </section>
  );
}

function GateSlot({
  operation,
  wire,
  index,
  onRemove,
}: {
  operation: GateOperation;
  wire: number;
  index: number;
  onRemove: (id: string) => void;
}) {
  const definition = GATE_DEFINITIONS[operation.kind];
  const involved = operation.target === wire || operation.control === wire;
  if (!involved) return <span className="gate-slot__spacer" aria-hidden="true" />;
  const isTarget = operation.target === wire;
  const label = operation.kind === "CNOT" && !isTarget
    ? "●"
    : operation.kind === "CNOT" && isTarget
      ? "⊕"
      : operation.kind === "SWAP"
        ? "×"
        : definition.label;
  return (
    <span className={`gate-slot ${isTarget ? "gate-slot--target" : "gate-slot--control"}`} style={{ animationDelay: `${index * 45}ms` }}>
      <span className="gate-slot__chip" aria-hidden="true">{label}</span>
      <span className="gate-slot__tooltip">
        {gateParameterLabel(operation.kind, operation.theta) || definition.name}
        {operation.control !== undefined ? ` · q${operation.control} → q${operation.target}` : ` · q${operation.target}`}
      </span>
      <button
        className="gate-slot__remove"
        type="button"
        aria-label={`Remove ${definition.name} gate, step ${index + 1}, wire q${wire}`}
        title="Remove gate"
        onClick={() => onRemove(operation.id)}
      >×</button>
    </span>
  );
}
