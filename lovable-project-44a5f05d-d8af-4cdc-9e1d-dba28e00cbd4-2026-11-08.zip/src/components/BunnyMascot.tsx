import type { CSSProperties } from "react";

interface BunnyMascotProps {
  mood?: "curious" | "happy" | "mischievous" | "thinking" | "celebrating";
  size?: number;
  compact?: boolean;
}

export default function BunnyMascot({
  mood = "curious",
  size = 150,
  compact = false,
}: BunnyMascotProps) {
  const style: CSSProperties = { width: size, height: size };
  return (
    <div className={`bunny-mascot bunny-mascot--${mood}${compact ? " bunny-mascot--compact" : ""}`} style={style} aria-label={`White bunny feeling ${mood}`} role="img">
      <svg viewBox="0 0 220 220" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <defs>
          <linearGradient id="bunny-fur" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#FFFFFF" />
            <stop offset="1" stopColor="#F1EAFB" />
          </linearGradient>
          <linearGradient id="bunny-ear" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#FFB7C9" />
            <stop offset="1" stopColor="#E58CA8" />
          </linearGradient>
          <filter id="bunny-shadow" x="-30%" y="-30%" width="160%" height="170%">
            <feDropShadow dx="0" dy="8" stdDeviation="8" floodColor="#5E477E" floodOpacity=".16" />
          </filter>
        </defs>
        <ellipse cx="110" cy="198" rx="65" ry="10" fill="#6B4D8C" opacity=".12" />
        <g className="bunny-ear-left" filter="url(#bunny-shadow)">
          <path d="M75 92 C48 61 42 11 61 8 C86 2 96 61 100 91Z" fill="url(#bunny-fur)" stroke="#E8DFF2" strokeWidth="2" />
          <path d="M73 70 C58 42 58 20 65 20 C78 20 84 51 87 72Z" fill="url(#bunny-ear)" />
        </g>
        <g className="bunny-ear-right" filter="url(#bunny-shadow)">
          <path d="M127 91 C126 47 141 3 163 11 C185 19 164 72 148 98Z" fill="url(#bunny-fur)" stroke="#E8DFF2" strokeWidth="2" />
          <path d="M139 76 C145 45 156 23 164 24 C174 26 154 65 147 81Z" fill="url(#bunny-ear)" />
        </g>
        <ellipse cx="111" cy="139" rx="66" ry="59" fill="url(#bunny-fur)" stroke="#E8DFF2" strokeWidth="2" filter="url(#bunny-shadow)" />
        <ellipse cx="60" cy="146" rx="16" ry="12" fill="#F6A9BD" opacity=".48" />
        <ellipse cx="162" cy="146" rx="16" ry="12" fill="#F6A9BD" opacity=".48" />
        <g className="bunny-eyes">
          <ellipse cx="88" cy="128" rx="6" ry="8" fill="#3A2B4D" />
          <ellipse cx="134" cy="128" rx="6" ry="8" fill="#3A2B4D" />
          <circle cx="90" cy="125" r="2" fill="white" />
          <circle cx="136" cy="125" r="2" fill="white" />
        </g>
        <path d="M105 143 Q111 137 117 143 Q111 151 105 143Z" fill="#E98DA8" />
        <path d="M111 150 Q106 159 99 155 M111 150 Q116 159 123 155" fill="none" stroke="#6E536F" strokeWidth="2.3" strokeLinecap="round" />
        <g className="bunny-mischief-mark">
          <path d="M151 105 l5 -8 l5 8 l-5 8Z" fill="#8F62CE" />
          <path d="M151 105 h10" stroke="#8F62CE" strokeWidth="2" />
        </g>
        <g className="bunny-bow">
          <path d="M75 174 Q57 158 54 176 Q61 190 78 180Z" fill="#A87AE2" />
          <path d="M81 174 Q100 158 102 176 Q94 190 80 180Z" fill="#C39AEF" />
          <circle cx="78" cy="176" r="5" fill="#8054BF" />
        </g>
        <g className="bunny-sparkles" fill="#F4B942">
          <path d="M177 62 l3 8 l8 3 l-8 3 l-3 8 l-3 -8 l-8 -3 l8 -3Z" />
          <path d="M40 100 l2 5 l5 2 l-5 2 l-2 5 l-2 -5 l-5 -2 l5 -2Z" />
        </g>
        <g className="bunny-carrot" transform="translate(145 166) rotate(28)">
          <path d="M-5 0 Q0 -9 5 0 L0 24Z" fill="#F39A36" />
          <path d="M0 0 Q-12 -12 -11 -18 Q-2 -15 0 -7 Q3 -18 12 -20 Q12 -7 3 0Z" fill="#72A66D" />
          <path d="M-1 7 l3 2 M0 14 l2 1" stroke="#D87526" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}
