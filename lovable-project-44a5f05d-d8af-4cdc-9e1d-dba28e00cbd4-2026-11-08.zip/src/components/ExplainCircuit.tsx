import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { explainCircuit } from "@/lib/explain.functions";

const box = { flex: 1, minWidth: 200, padding: 8, borderRadius: 8, border: "1px solid currentColor" } as const;

export default function ExplainCircuit({ circuit }: { circuit: string }) {
  const run = useServerFn(explainCircuit);
  const [c, setC] = useState(circuit);
  const [o, setO] = useState("");
  const [out, setOut] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => setC(circuit), [circuit]);

  const go = async () => {
    if (!c.trim()) return setErr("Add a circuit first.");
    setBusy(true); setErr(null);
    try {
      const r = await run({ data: { circuit: c, output: o } });
      if (r.error) setErr(r.error); else setOut(r.text);
    } catch { setErr("Good Bunny couldn't explain right now. Please try again."); }
    finally { setBusy(false); }
  };

  return (
    <section className="learning-panel" style={{ marginTop: 16 }}>
      <h3>🔍 Explain my circuit</h3>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <input value={c} onChange={(e) => setC(e.target.value)} maxLength={1000} placeholder="Circuit, e.g. H@q0, CNOT@q1(ctrl q0)" style={box} />
        <input value={o} onChange={(e) => setO(e.target.value)} maxLength={500} placeholder="What you saw, e.g. 00 half the time, 11 half" style={box} />
        <button type="button" onClick={go} disabled={busy}>{busy ? "Explaining…" : "Explain"}</button>
      </div>
      {out && <p style={{ marginTop: 10, whiteSpace: "pre-line" }}>{out}</p>}
      {err && <p key={err} role="alert" className="inline-error" style={{ marginTop: 10 }}>{err}</p>}
    </section>
  );
}
