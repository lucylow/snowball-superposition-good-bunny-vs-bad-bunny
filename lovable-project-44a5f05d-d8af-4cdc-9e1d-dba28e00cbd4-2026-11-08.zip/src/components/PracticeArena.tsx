import { useMemo, useState } from "react";
import { PRACTICE_CHALLENGES, type ChallengeTopic } from "../content/challenges";
import BunnyMascot from "./BunnyMascot";

const TOPICS: { value: ChallengeTopic | "all"; label: string }[] = [
  { value: "all", label: "All carrot topics" },
  { value: "qubits", label: "Qubits" },
  { value: "superposition", label: "Superposition" },
  { value: "single-gates", label: "Single-qubit gates" },
  { value: "phase", label: "Phase" },
  { value: "rotations", label: "Rotations" },
  { value: "entanglement", label: "Entanglement" },
  { value: "measurement", label: "Measurement" },
];

export default function PracticeArena() {
  const [topic, setTopic] = useState<ChallengeTopic | "all">("all");
  const [position, setPosition] = useState(0);
  const [answer, setAnswer] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [hintOpen, setHintOpen] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredIds, setAnsweredIds] = useState<string[]>([]);
  const [sessionDone, setSessionDone] = useState(false);

  const challenges = useMemo(() => {
    const filtered = topic === "all"
      ? PRACTICE_CHALLENGES
      : PRACTICE_CHALLENGES.filter((challenge) => challenge.topic === topic);
    return filtered;
  }, [topic]);
  const challenge = challenges[position];
  const correct = answer === challenge?.correctIndex;
  const percent = challenges.length > 0 ? Math.round((answeredIds.length / challenges.length) * 100) : 0;

  const changeTopic = (nextTopic: ChallengeTopic | "all") => {
    setTopic(nextTopic);
    setPosition(0);
    setAnswer(null);
    setSubmitted(false);
    setHintOpen(false);
    setScore(0);
    setAnsweredIds([]);
    setSessionDone(false);
  };

  const submit = () => {
    if (answer === null || submitted || !challenge) return;
    setSubmitted(true);
    setAnsweredIds((ids) => [...ids, challenge.id]);
    if (answer === challenge.correctIndex) setScore((value) => value + challenge.carrots);
  };

  const next = () => {
    if (position + 1 >= challenges.length) {
      setSessionDone(true);
      return;
    }
    setPosition((value) => value + 1);
    setAnswer(null);
    setSubmitted(false);
    setHintOpen(false);
  };

  const restart = () => {
    setPosition(0);
    setAnswer(null);
    setSubmitted(false);
    setHintOpen(false);
    setScore(0);
    setAnsweredIds([]);
    setSessionDone(false);
  };

  return (
    <main className="practice-page">
      <div className="practice-hero">
        <BunnyMascot mood="celebrating" size={132} />
        <div>
          <span className="eyebrow">THE CARROT ARCADE</span>
          <h1>Quantum snack attack!</h1>
          <p>Quick-fire questions to make those quantum circuit ideas stick. Earn practice carrots for every correct answer.</p>
          <div className="practice-stats"><span>⚛️ {challenges.length} challenges</span><span>🥕 {score} practice carrots</span></div>
        </div>
      </div>

      <div className="practice-toolbar">
        <label htmlFor="practice-topic">Pick a topic</label>
        <select id="practice-topic" value={topic} onChange={(event) => changeTopic(event.target.value as ChallengeTopic | "all")}>
          {TOPICS.map((entry) => <option value={entry.value} key={entry.value}>{entry.label}</option>)}
        </select>
        <div className="practice-progress"><span style={{ width: `${percent}%` }} /></div>
        <span>{answeredIds.length}/{challenges.length} answered</span>
      </div>

      {sessionDone ? (
        <section className="practice-finish">
          <BunnyMascot mood="celebrating" size={128} />
          <span className="eyebrow">ARCADE SESSION COMPLETE</span>
          <h2>That was a lot of brain carrots!</h2>
          <div className="practice-final-score">🥕 {score} practice carrots</div>
          <p>You answered {answeredIds.length} questions. Keep hopping through the topics to strengthen your circuit instincts.</p>
          <button type="button" className="button button--primary" onClick={restart}>Play this set again</button>
        </section>
      ) : challenge ? (
        <section className="challenge-card">
          <div className="challenge-card__top">
            <div><span className="eyebrow">CHALLENGE {String(position + 1).padStart(2, "0")}</span><h2>{challenge.topic.replace("-", " ")}</h2></div>
            <span className={`difficulty difficulty--${challenge.difficulty}`}>{challenge.difficulty}</span>
          </div>
          <div className="challenge-prompt"><span className="challenge-carrot">🥕</span><p>{challenge.prompt}</p></div>
          <div className="challenge-options">
            {challenge.choices.map((choice, index) => (
              <button
                key={`${challenge.id}-${index}`}
                type="button"
                className={`challenge-option${answer === index ? " is-selected" : ""}${submitted && index === challenge.correctIndex ? " is-correct" : ""}${submitted && answer === index && !correct ? " is-wrong" : ""}`}
                onClick={() => !submitted && setAnswer(index)}
                disabled={submitted}
              >
                <span className="challenge-option__letter">{String.fromCharCode(65 + index)}</span>
                <span>{choice}</span>
                {submitted && index === challenge.correctIndex && <strong>✓</strong>}
              </button>
            ))}
          </div>
          {!submitted && (
            <div className="challenge-actions">
              <button type="button" className="hint-button" onClick={() => setHintOpen((value) => !value)}>🥕 {hintOpen ? "Hide hint" : "Get a hint"}</button>
              <button type="button" className="button button--primary" disabled={answer === null} onClick={submit}>Check answer</button>
            </div>
          )}
          {hintOpen && !submitted && <div className="challenge-hint">💡 {challenge.hint}</div>}
          {submitted && (
            <div className={`challenge-feedback${correct ? " challenge-feedback--correct" : " challenge-feedback--wrong"}`}>
              <strong>{correct ? `Nice hopping! +${challenge.carrots} practice carrots.` : "A little quantum wobble - try the next one!"}</strong>
              <p>{challenge.explanation}</p>
              <button type="button" className="button button--primary" onClick={next}>{position + 1 === challenges.length ? "Finish arcade set" : "Next challenge →"}</button>
            </div>
          )}
          <div className="challenge-card__footer"><span>ONE BUNNY · TWO BASIS LABELS</span><span>Practice rewards are separate from campaign carrots.</span></div>
        </section>
      ) : (
        <section className="practice-finish"><h2>No challenges in this topic yet.</h2><button type="button" onClick={() => changeTopic("all")}>Show all topics</button></section>
      )}
    </main>
  );
}
