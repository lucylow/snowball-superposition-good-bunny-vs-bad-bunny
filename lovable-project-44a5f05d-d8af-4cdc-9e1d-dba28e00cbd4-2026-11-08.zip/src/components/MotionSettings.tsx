import { useEffect, useState } from "react";

type Intensity = "off" | "calm" | "full";
const KEY = "gb-motion";

export default function MotionSettings() {
  const [open, setOpen] = useState(false);
  const [intensity, setIntensity] = useState<Intensity>("full");
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem(KEY) || "{}");
      if (s.intensity) setIntensity(s.intensity);
      if (s.paused) setPaused(true);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset["motion"] = intensity;
    root.dataset["motionPaused"] = paused ? "true" : "false";
    localStorage.setItem(KEY, JSON.stringify({ intensity, paused }));
  }, [intensity, paused]);

  const replay = () => {
    const root = document.documentElement;
    setPaused(false);
    root.classList.add("gb-replay");
    void root.offsetWidth;
    requestAnimationFrame(() => root.classList.remove("gb-replay"));
  };

  return (
    <div className="motion-settings">
      <button type="button" className="icon-button" aria-label="Animation settings" aria-expanded={open} title="Animation settings" onClick={() => setOpen(!open)}>✨</button>
      {open && (
        <div className="motion-panel" role="dialog" aria-label="Animation settings">
          <strong>Animations</strong>
          <div className="motion-segment" role="radiogroup" aria-label="Animation intensity">
            {(["off", "calm", "full"] as Intensity[]).map((v) => (
              <button key={v} type="button" role="radio" aria-checked={intensity === v} className={intensity === v ? "is-active" : ""} onClick={() => setIntensity(v)}>
                {v === "off" ? "Off" : v === "calm" ? "Calm" : "Full"}
              </button>
            ))}
          </div>
          <div className="motion-actions">
            <button type="button" onClick={() => setPaused(!paused)} disabled={intensity === "off"}>{paused ? "▶ Resume" : "⏸ Pause"}</button>
            <button type="button" onClick={replay} disabled={intensity === "off"}>↺ Replay</button>
          </div>
        </div>
      )}
    </div>
  );
}
