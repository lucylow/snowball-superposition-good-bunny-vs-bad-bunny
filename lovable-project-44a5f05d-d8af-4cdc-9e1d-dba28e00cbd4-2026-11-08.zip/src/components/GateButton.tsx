import { GATE_DEFINITIONS, type GateKind } from "../quantum/gates";

interface GateButtonProps {
  kind: GateKind;
  selected?: boolean;
  disabled?: boolean;
  onClick: (kind: GateKind) => void;
}

const GATE_COLORS: Record<GateKind, string> = {
  H: "gate--superposition",
  X: "gate--flip",
  Y: "gate--phase",
  Z: "gate--phase",
  S: "gate--phase",
  T: "gate--phase",
  RX: "gate--rotation",
  RY: "gate--rotation",
  RZ: "gate--rotation",
  CNOT: "gate--controlled",
  CZ: "gate--controlled",
  SWAP: "gate--controlled",
  MEASURE: "gate--measure",
};

export default function GateButton({ kind, selected, disabled, onClick }: GateButtonProps) {
  const definition = GATE_DEFINITIONS[kind];
  return (
    <button
      className={`gate-button ${GATE_COLORS[kind]}${selected ? " is-selected" : ""}`}
      type="button"
      disabled={disabled}
      onClick={() => onClick(kind)}
      title={`${definition.name}: ${definition.description}`}
      aria-pressed={selected ?? false}
    >
      <span className="gate-button__symbol">{definition.label}</span>
      <span className="gate-button__name">{definition.name}</span>
    </button>
  );
}
