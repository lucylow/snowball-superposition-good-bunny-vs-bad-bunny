import { useState } from "react";
import { GATE_DEFINITIONS, type GateKind } from "../quantum/gates";
import GateButton from "./GateButton";

interface GateShelfProps {
  onAdd: (kind: GateKind) => void;
  disabled?: boolean;
  onGatePreview?: (kind: GateKind) => void;
}

const GROUPS: { title: string; note: string; gates: GateKind[] }[] = [
  { title: "Foundation", note: "Start here", gates: ["H", "X"] },
  { title: "Phase garden", note: "Tune the phase", gates: ["Y", "Z", "S", "T"] },
  { title: "Rotations", note: "Choose an angle", gates: ["RX", "RY", "RZ"] },
  { title: "Two-wire tricks", note: "Connect qubits", gates: ["CNOT", "CZ", "SWAP"] },
  { title: "Readout", note: "Observe the result", gates: ["MEASURE"] },
];

export default function GateShelf({ onAdd, disabled = false, onGatePreview }: GateShelfProps) {
  const [selected, setSelected] = useState<GateKind | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const choose = (kind: GateKind) => {
    setSelected(kind);
    setDetailsOpen(true);
    onGatePreview?.(kind);
    onAdd(kind);
  };

  return (
    <section className="gate-shelf">
      <div className="gate-shelf__heading">
        <div>
          <span className="eyebrow">CARROT-POWERED COMPONENTS</span>
          <h3>Gate shelf</h3>
        </div>
        <span className="shelf-count">13 quantum tools</span>
      </div>
      <div className="gate-groups">
        {GROUPS.map((group) => (
          <div className="gate-group" key={group.title}>
            <div className="gate-group__heading">
              <strong>{group.title}</strong>
              <span>{group.note}</span>
            </div>
            <div className="gate-group__buttons">
              {group.gates.map((kind) => (
                <GateButton
                  key={kind}
                  kind={kind}
                  selected={selected === kind}
                  disabled={disabled}
                  onClick={choose}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
      {detailsOpen && selected && (
        <div className="gate-shelf__detail">
          <span className="detail-symbol">{GATE_DEFINITIONS[selected].label}</span>
          <div>
            <strong>{GATE_DEFINITIONS[selected].name}</strong>
            <p>{GATE_DEFINITIONS[selected].description}</p>
            <small>🥕 Bunny tip: {GATE_DEFINITIONS[selected].bunnyTip}</small>
          </div>
          <button type="button" className="icon-button" onClick={() => setDetailsOpen(false)} aria-label="Close gate details">×</button>
        </div>
      )}
    </section>
  );
}
