import { cleanNumber, formatComplex, magnitudeSquared } from "../quantum/complex";
import { formatBlochCoordinate, getBlochVector } from "../quantum/bloch";
import type { QuantumState } from "../quantum/stateVector";
import { indexToBitString } from "../quantum/stateVector";

interface ProbabilityPanelProps {
  state: QuantumState;
  collapsed?: boolean;
}

export default function ProbabilityPanel({ state, collapsed = false }: ProbabilityPanelProps) {
  const bloch = getBlochVector(state, 0);
  const rows = state.amplitudes
    .map((amplitude, index) => ({
      bits: indexToBitString(index, state.qubitCount),
      amplitude,
      probability: magnitudeSquared(amplitude),
    }))
    .filter((row) => row.probability > 1e-8);
  return (
    <section className="probability-panel">
      <div className="probability-panel__heading">
        <div>
          <span className="eyebrow">STATE INSPECTOR</span>
          <h3>{collapsed ? "Measured state" : "Quantum amplitudes"}</h3>
        </div>
        <span className="qubit-pill">{state.qubitCount} qubit{state.qubitCount === 1 ? "" : "s"}</span>
      </div>
      <div className="amplitude-list">
        {rows.map((row) => (
          <div className="amplitude-row" key={row.bits}>
            <div className="amplitude-row__label">
              <strong>|{row.bits}⟩</strong>
              <span>{formatComplex(row.amplitude, 3)}</span>
            </div>
            <div className="amplitude-meter">
              <span style={{ width: `${Math.min(100, row.probability * 100)}%` }} />
            </div>
            <strong className="amplitude-percent">{cleanNumber(row.probability * 100, 1)}%</strong>
          </div>
        ))}
      </div>
      <div className="bloch-readout">
        <div className="bloch-readout__top">
          <strong>Qubit q0 · Bloch coordinates</strong>
          <span>{bloch.radius > 0.999 ? "Pure reduced state" : "Mixed reduced state"}</span>
        </div>
        <div className="bloch-coordinates">
          <span><b>X</b>{formatBlochCoordinate(bloch.x)}</span>
          <span><b>Y</b>{formatBlochCoordinate(bloch.y)}</span>
          <span><b>Z</b>{formatBlochCoordinate(bloch.z)}</span>
          <span><b>Purity</b>{formatBlochCoordinate(bloch.purity)}</span>
          <span><b>Entropy</b>{formatBlochCoordinate(bloch.entropyBits)} bits</span>
        </div>
      </div>
      <div className="basis-legend">
        {state.qubitCount === 1 ? (
          <>
            <span><i className="legend-dot legend-dot--good" /> |0⟩ = Good label</span>
            <span><i className="legend-dot legend-dot--bad" /> |1⟩ = Bad label</span>
          </>
        ) : (
          <span>Bit strings are displayed in q{state.qubitCount - 1}…q0 order.</span>
        )}
      </div>
      <p className="inspector-note">
        {collapsed
          ? "The measured qubit has collapsed to the observed outcome."
          : "Bar length shows measurement probability; phase is shown in the complex amplitude."}
      </p>
    </section>
  );
}
