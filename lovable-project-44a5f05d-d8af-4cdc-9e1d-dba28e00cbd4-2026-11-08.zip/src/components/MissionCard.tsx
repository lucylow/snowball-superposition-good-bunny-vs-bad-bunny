import type { Mission } from "../game/types";
import BunnyMascot from "./BunnyMascot";

interface MissionCardProps {
  mission: Mission;
  completed: boolean;
  onSelect: () => void;
  active?: boolean;
  locked?: boolean;
}

const DIFFICULTY_LABEL: Record<Mission["difficulty"], string> = {
  starter: "Warm-up",
  easy: "Easy",
  medium: "Medium",
  advanced: "Spicy",
};

export default function MissionCard({ mission, completed, onSelect, active, locked }: MissionCardProps) {
  return (
    <button
      type="button"
      className={`mission-card${active ? " mission-card--active" : ""}${completed ? " mission-card--complete" : ""}${locked ? " mission-card--locked" : ""}`}
      onClick={onSelect}
      disabled={locked}
    >
      <span className="mission-card__number">{completed ? "✓" : locked ? "🔒" : String(mission.number).padStart(2, "0")}</span>
      <span className="mission-card__copy">
        <strong>{mission.title}</strong>
        <small>{mission.chapter} · {DIFFICULTY_LABEL[mission.difficulty]}</small>
      </span>
      <span className="mission-card__reward">🥕 {mission.carrotReward}</span>
    </button>
  );
}

export function MissionIntro({ mission }: { mission: Mission }) {
  return (
    <div className="mission-intro">
      <div className="mission-intro__bunny"><BunnyMascot mood="mischievous" size={102} compact /></div>
      <div className="mission-intro__copy">
        <span className="eyebrow">CHAPTER {mission.number.toString().padStart(2, "0")} · {mission.chapter.toUpperCase()}</span>
        <h2>{mission.title}</h2>
        <p>{mission.story}</p>
      </div>
      <div className="mission-intro__reward">🥕 +{mission.carrotReward}</div>
    </div>
  );
}
