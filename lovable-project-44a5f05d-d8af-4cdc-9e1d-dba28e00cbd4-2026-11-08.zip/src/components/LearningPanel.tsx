import { useState } from "react";
import type { Mission } from "../game/types";
import { GATE_DEFINITIONS, type GateKind } from "../quantum/gates";

interface LearningPanelProps {
  mission: Mission;
  recentGate?: GateKind | null;
}

export default function LearningPanel({ mission, recentGate }: LearningPanelProps) {
  const [showHint, setShowHint] = useState(false);
  const [showLesson, setShowLesson] = useState(true);
  const [showGlossary, setShowGlossary] = useState(false);
  const gate = recentGate ? GATE_DEFINITIONS[recentGate] : undefined;

  return (
    <section className="learning-panel">
      <div className="learning-panel__heading">
        <div>
          <span className="eyebrow">BUNNY BRAIN BOOST</span>
          <h3>What are we learning?</h3>
        </div>
        <span className="learning-icon">🧠</span>
      </div>
      <div className="learning-panel__objective">
        <span className="objective-label">YOUR MISSION</span>
        <p>{mission.objective}</p>
      </div>
      <button
        type="button"
        className="learning-toggle"
        onClick={() => setShowLesson((value) => !value)}
        aria-expanded={showLesson}
      >
        <span>⚛️ Quantum snack-sized lesson</span>
        <span>{showLesson ? "−" : "+"}</span>
      </button>
      {showLesson && <p className="lesson-copy">{mission.lesson}</p>}
      {gate && (
        <div className="recent-gate-note">
          <strong>Gate just added: {gate.name}</strong>
          <p>{gate.bunnyTip}</p>
        </div>
      )}
      <button
        type="button"
        className="hint-button"
        onClick={() => setShowHint((value) => !value)}
        aria-expanded={showHint}
      >
        🥕 {showHint ? "Hide carrot clue" : "Need a carrot clue?"}
      </button>
      {showHint && <p className="hint-copy">{mission.hint}</p>}
      <button
        type="button"
        className="glossary-button"
        onClick={() => setShowGlossary((value) => !value)}
      >
        {showGlossary ? "Hide" : "Open"} the bunny quantum glossary
      </button>
      {showGlossary && <MiniGlossary />}
    </section>
  );
}

function MiniGlossary() {
  const terms = [
    ["Qubit", "A quantum system with two basis states, |0> and |1>."],
    ["Amplitude", "A complex number whose squared magnitude contributes to probability."],
    ["Superposition", "A quantum state that is a linear combination of basis states."],
    ["Phase", "The angle of a complex amplitude; relative phase can change interference."],
    ["Entanglement", "A joint quantum state that cannot be factored into separate states of each qubit."],
    ["Measurement", "An observation that returns an outcome according to the state probabilities."],
  ];
  return (
    <dl className="mini-glossary">
      {terms.map(([term, definition]) => (
        <div key={term}>
          <dt>{term}</dt>
          <dd>{definition}</dd>
        </div>
      ))}
    </dl>
  );
}
