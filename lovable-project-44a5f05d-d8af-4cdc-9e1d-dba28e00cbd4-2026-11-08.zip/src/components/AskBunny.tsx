import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { askMissionHint } from "@/lib/hint.functions";
import type { Mission } from "@/game/types";

export default function AskBunny({ mission, circuit }: { mission: Mission; circuit: string }) {
  const ask = useServerFn(askMissionHint);
  const [q, setQ] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim() || busy) return;
    setBusy(true); setErr(null); setAnswer(null);
    try {
      const r = await ask({ data: { question: q, title: mission.title, objective: mission.objective, lesson: mission.lesson, hint: mission.hint, circuit } });
      if (r.error) setErr(r.error); else setAnswer(r.hint);
    } catch {
      setErr("Good Bunny couldn't answer right now. Please try again.");
    } finally { setBusy(false); }
  };

  return (
    <section className="learning-panel" style={{ marginTop: 16 }}>
      <h3>🐰 Ask Good Bunny</h3>
      <form onSubmit={submit} style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} maxLength={500}
          placeholder="Stuck? Ask about this mission…" style={{ flex: 1, minWidth: 200, padding: 8, borderRadius: 8, border: "1px solid currentColor" }} />
        <button type="submit" disabled={busy || !q.trim()}>{busy ? "Thinking…" : "Get hint"}</button>
      </form>
      {answer && <p style={{ marginTop: 10 }}>{answer}</p>}
      {err && <p key={err} role="alert" className="inline-error" style={{ marginTop: 10 }}>{err}</p>}
    </section>
  );
}
