import { useEffect, useRef, useState } from "react";
import type { PlayerProgress } from "@/game/types";
import { getBadges, getLevel, getRank } from "@/game/rewards";

export default function RewardsBar({ progress, totalMissions }: { progress: PlayerProgress; totalMissions: number }) {
  const lv = getLevel(progress.carrotCount);
  const badges = getBadges(progress, totalMissions);
  const earned = badges.filter((b) => b.earned).length;
  const prev = useRef<{ level: number; earned: number } | null>(null);
  const [celebrate, setCelebrate] = useState<string | null>(null);

  useEffect(() => {
    const p = prev.current;
    if (p && lv.level > p.level) setCelebrate(`Level up! You're now a ${getRank(lv.level)} 🎉`);
    else if (p && earned > p.earned) setCelebrate(`New badge unlocked: ${badges.filter((b) => b.earned).at(-1)?.name} 🏅`);
    prev.current = { level: lv.level, earned };
  }, [lv.level, earned]);

  useEffect(() => {
    if (!celebrate) return;
    const t = setTimeout(() => setCelebrate(null), 3500);
    return () => clearTimeout(t);
  }, [celebrate]);

  return (
    <section className="learning-panel" style={{ marginBottom: 16 }} aria-label="Your rewards">
      <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
        <strong>Level {lv.level} · {getRank(lv.level)}</strong>
        <span>{lv.into}/{lv.needed} 🥕 to next level · {earned}/{badges.length} badges</span>
      </div>
      <div style={{ height: 10, borderRadius: 99, background: "rgba(0,0,0,.08)", margin: "8px 0", overflow: "hidden" }}>
        <div style={{ width: `${lv.pct}%`, height: "100%", background: "linear-gradient(90deg,#f7a046,#f06f3c)", transition: "width .6s" }} />
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {badges.map((b) => (
          <span key={b.id} title={`${b.name} — ${b.desc}`}
            style={{ padding: "4px 10px", borderRadius: 99, border: "1px solid rgba(0,0,0,.12)", opacity: b.earned ? 1 : 0.35, filter: b.earned ? "none" : "grayscale(1)" }}>
            {b.icon} {b.name}
          </span>
        ))}
      </div>
      {celebrate && <p role="status" style={{ marginTop: 8, fontWeight: 700 }}>{celebrate}</p>}
    </section>
  );
}
